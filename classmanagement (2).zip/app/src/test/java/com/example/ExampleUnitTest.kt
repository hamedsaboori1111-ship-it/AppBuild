package com.example

import com.example.model.Student
import com.example.util.DateUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDateUtils_PersianDigits() {
    val englishDigits = "1403/07/15"
    val persianDigits = DateUtils.toPersianDigits(englishDigits)
    assertEquals("۱۴۰۳/۰۷/۱۵", persianDigits)
    assertEquals("1403/07/15", DateUtils.toEnglishDigits(persianDigits))
  }

  @Test
  fun testStudentBirthMonthDetection() {
    val s1 = Student(id = 1, name = "علی حسینی", birthDate = "۱۳۹۴/۰۷/۱۰", birthMonth = "مهر")
    val s2 = Student(id = 2, name = "رضا محمدی", birthDate = "۱۳۹۴/۰۸/۲۲", birthMonth = "آبان")

    val allPersianMonths = listOf(
      "فروردین", "اردیبهشت", "خرداد",
      "تیر", "مرداد", "شهریور",
      "مهر", "آبان", "آذر",
      "دی", "بهمن", "اسفند"
    )

    fun isStudentBornInTargetMonth(student: Student, targetMonth: String): Boolean {
      if (student.birthMonth.trim().equals(targetMonth.trim(), ignoreCase = true)) return true
      if (student.birthDate.isNotBlank()) {
        val eng = DateUtils.toEnglishDigits(student.birthDate)
        val parts = eng.split("/")
        if (parts.size >= 2) {
          val m = parts[1].toIntOrNull()
          if (m != null && m in 1..12) {
            if (allPersianMonths[m - 1] == targetMonth) return true
          }
        }
      }
      return false
    }

    assertTrue(isStudentBornInTargetMonth(s1, "مهر"))
    assertFalse(isStudentBornInTargetMonth(s1, "آبان"))
    assertTrue(isStudentBornInTargetMonth(s2, "آبان"))
    assertFalse(isStudentBornInTargetMonth(s2, "مهر"))
  }
}

