package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.util.DateUtils
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LocalBackupFile(
    val file: File,
    val title: String,
    val dateShamsi: String,
    val time: String,
    val sizeBytes: Long,
    val sizeFormatted: String,
    val studentsCount: Int,
    val evaluationsCount: Int,
    val attendanceDaysCount: Int,
    val subjectsCount: Int,
    val notesCount: Int,
    val teacherName: String,
    val isAutoBackup: Boolean,
    val lastModified: Long
)

data class BackupSummary(
    val isValid: Boolean,
    val title: String,
    val dateShamsi: String,
    val teacherName: String,
    val schoolName: String,
    val studentsCount: Int,
    val evaluationsCount: Int,
    val attendanceDaysCount: Int,
    val subjectsCount: Int,
    val notesCount: Int,
    val groupsCount: Int,
    val meetingsCount: Int,
    val errorMessage: String? = null
)

class BackupManager(private val context: Context) {

    private val backupDir: File
        get() = File(context.filesDir, "backups").apply {
            if (!exists()) {
                mkdirs()
            }
        }

    fun listLocalBackups(): List<LocalBackupFile> {
        val dir = backupDir
        if (!dir.exists()) return emptyList()

        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") } ?: return emptyList()

        return files.mapNotNull { file ->
            try {
                parseFileToLocalBackup(file)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }.sortedByDescending { it.lastModified }
    }

    private fun parseFileToLocalBackup(file: File): LocalBackupFile {
        val content = file.readText(Charsets.UTF_8)
        val summary = parseBackupSummary(content)
        val sizeBytes = file.length()
        val sizeFormatted = formatFileSize(sizeBytes)

        val isAuto = file.name.startsWith("auto_backup_")

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val timeString = DateUtils.toPersianDigits(timeFormat.format(Date(file.lastModified())))

        val cleanTitle = if (isAuto) {
            "پشتیبان خودکار روزانه"
        } else {
            val nameWithoutExt = file.nameWithoutExtension
            if (nameWithoutExt.startsWith("backup_")) {
                val custom = nameWithoutExt.substringAfter("backup_")
                if (custom.isNotBlank()) custom.replace("_", " ") else "نسخه دستی کلاس"
            } else {
                nameWithoutExt.replace("_", " ")
            }
        }

        val dateShamsi = if (summary.dateShamsi.isNotBlank()) {
            DateUtils.toPersianDigits(summary.dateShamsi)
        } else {
            DateUtils.toPersianDigits(DateUtils.getCurrentShamsiDate())
        }

        return LocalBackupFile(
            file = file,
            title = cleanTitle,
            dateShamsi = dateShamsi,
            time = timeString,
            sizeBytes = sizeBytes,
            sizeFormatted = sizeFormatted,
            studentsCount = summary.studentsCount,
            evaluationsCount = summary.evaluationsCount,
            attendanceDaysCount = summary.attendanceDaysCount,
            subjectsCount = summary.subjectsCount,
            notesCount = summary.notesCount,
            teacherName = summary.teacherName,
            isAutoBackup = isAuto,
            lastModified = file.lastModified()
        )
    }

    fun parseBackupSummary(jsonString: String): BackupSummary {
        return try {
            val root = JSONObject(jsonString)
            val studentsArr = root.optJSONArray("students")
            val studentsCount = studentsArr?.length() ?: 0
            var evaluationsCount = 0

            if (studentsArr != null) {
                for (i in 0 until studentsArr.length()) {
                    val s = studentsArr.optJSONObject(i)
                    evaluationsCount += s?.optJSONArray("evaluations")?.length() ?: 0
                }
            }

            val attendanceArr = root.optJSONArray("attendanceHistory")
            val attendanceDaysCount = attendanceArr?.length() ?: 0

            val subjectsArr = root.optJSONArray("subjects")
            val subjectsCount = subjectsArr?.length() ?: 0

            val notesArr = root.optJSONArray("teacherNotes")
            val notesCount = notesArr?.length() ?: 0

            val groupsArr = root.optJSONArray("groups")
            val groupsCount = groupsArr?.length() ?: 0

            val meetingsArr = root.optJSONArray("parentMeetings")
            val meetingsCount = meetingsArr?.length() ?: 0

            val profileObj = root.optJSONObject("profile")
            val teacherName = profileObj?.optString("teacherName", "معلم گرامی") ?: "معلم گرامی"
            val schoolName = profileObj?.optString("schoolName", "") ?: ""
            val dateShamsi = root.optString("currentDateShamsi", "")

            BackupSummary(
                isValid = true,
                title = "اطلاعات کلاس",
                dateShamsi = dateShamsi,
                teacherName = teacherName,
                schoolName = schoolName,
                studentsCount = studentsCount,
                evaluationsCount = evaluationsCount,
                attendanceDaysCount = attendanceDaysCount,
                subjectsCount = subjectsCount,
                notesCount = notesCount,
                groupsCount = groupsCount,
                meetingsCount = meetingsCount
            )
        } catch (e: Exception) {
            BackupSummary(
                isValid = false,
                title = "فایل نامعتبر",
                dateShamsi = "",
                teacherName = "",
                schoolName = "",
                studentsCount = 0,
                evaluationsCount = 0,
                attendanceDaysCount = 0,
                subjectsCount = 0,
                notesCount = 0,
                groupsCount = 0,
                meetingsCount = 0,
                errorMessage = e.localizedMessage ?: "قالب فایل نامعتبر است"
            )
        }
    }

    fun createLocalBackup(
        stateJson: String,
        customTitle: String? = null,
        isAutoBackup: Boolean = false
    ): LocalBackupFile? {
        return try {
            val timestamp = System.currentTimeMillis()
            val dateShamsi = DateUtils.getCurrentShamsiDate().replace("/", "-")
            val timeFormat = SimpleDateFormat("HHmm", Locale.getDefault())
            val timeStr = timeFormat.format(Date(timestamp))

            val fileName = if (isAutoBackup) {
                "auto_backup_$dateShamsi.json"
            } else {
                val safeTitle = (customTitle?.trim()?.replace(" ", "_")?.takeIf { it.isNotBlank() }
                    ?: "دستی_$dateShamsi-$timeStr")
                "backup_$safeTitle.json"
            }

            val targetFile = File(backupDir, fileName)
            targetFile.writeText(stateJson, Charsets.UTF_8)
            parseFileToLocalBackup(targetFile)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteBackup(file: File): Boolean {
        return try {
            if (file.exists()) file.delete() else true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun readBackupFile(file: File): String? {
        return try {
            if (file.exists()) file.readText(Charsets.UTF_8) else null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun writeToUri(uri: Uri, content: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(content.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun readFromUri(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { ins ->
                ins.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareBackupFile(context: Context, file: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val fileUri = FileProvider.getUriForFile(context, authority, file)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, "نسخه پشتیبان اطلاعات کلاس - ${file.name}")
                putExtra(Intent.EXTRA_TEXT, "نسخه پشتیبان اطلاعات کلاس درس و ارزیابی دانش‌آموزان")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل پشتیبان کلاس"))
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback: share content as text
            val text = readBackupFile(file) ?: return
            val textIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "نسخه پشتیبان اطلاعات کلاس")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(textIntent, "اشتراک‌گذاری اطلاعات پشتیبان"))
        }
    }

    fun autoBackupIfDue(stateJson: String) {
        try {
            val dateShamsi = DateUtils.getCurrentShamsiDate().replace("/", "-")
            val autoFile = File(backupDir, "auto_backup_$dateShamsi.json")
            if (!autoFile.exists()) {
                createLocalBackup(stateJson, isAutoBackup = true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "${DateUtils.toPersianDigits(bytes.toString())} بایت"
            bytes < 1024 * 1024 -> {
                val kb = bytes / 1024.0
                val formatted = String.format(Locale.US, "%.1f", kb)
                "${DateUtils.toPersianDigits(formatted)} کیلوبایت"
            }
            else -> {
                val mb = bytes / (1024.0 * 1024.0)
                val formatted = String.format(Locale.US, "%.1f", mb)
                "${DateUtils.toPersianDigits(formatted)} مگابایت"
            }
        }
    }
}
