package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BackupSummary
import com.example.data.LocalBackupFile
import com.example.ui.theme.*
import com.example.util.DateUtils
import com.example.viewmodel.ClassViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: ClassViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    var localBackups by remember { mutableStateOf(listOf<LocalBackupFile>()) }

    fun refreshBackupsList() {
        localBackups = viewModel.listLocalBackups()
    }

    LaunchedEffect(Unit) {
        refreshBackupsList()
    }

    // Dialog states
    var showCreateBackupDialog by remember { mutableStateOf(false) }
    var backupCustomTitle by remember { mutableStateOf("") }

    var backupToRestore by remember { mutableStateOf<LocalBackupFile?>(null) }
    var backupToDelete by remember { mutableStateOf<LocalBackupFile?>(null) }

    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingRestoreSummary by remember { mutableStateOf<BackupSummary?>(null) }

    var showTextCodeDialog by remember { mutableStateOf(false) }
    var textCodeMode by remember { mutableStateOf("export") } // "export" or "import"
    var rawTextCode by remember { mutableStateOf("") }

    // SAF Create Document launcher (خروجی به فایل انتخابی در حافظه گوشی)
    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val success = viewModel.exportBackupToUri(uri)
            if (success) {
                Toast.makeText(
                    context,
                    "فایل پشتیبان با موفقیت در حافظه گوشی ذخیره شد.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    context,
                    "خطا در ذخیره‌سازی فایل در محل انتخاب شده!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // SAF Open Document launcher (بازیابی از فایل انتخابی در حافظه گوشی)
    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.use {
                    it.bufferedReader(Charsets.UTF_8).readText()
                }
                if (json != null) {
                    val summary = viewModel.parseBackupSummary(json)
                    if (summary.isValid) {
                        pendingRestoreUri = uri
                        pendingRestoreSummary = summary
                    } else {
                        Toast.makeText(
                            context,
                            "فایل انتخاب شده ساختار معتبر اطلاعات کلاس را ندارد!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "خطا در خواندن فایل انتخاب‌شده!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Calculate live total stats
    val totalEvaluationsCount = remember(state.students) {
        state.students.sumOf { it.evaluations.size }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ذخیره و بازیابی اطلاعات کلاس",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("backup_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { refreshBackupsList() },
                        modifier = Modifier.testTag("backup_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تازه‌سازی فهرست"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ۱. بنر آرامش خاطر و وضعیت امنیت ارزیابی‌ها
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        PrimaryGreenDark.copy(alpha = 0.95f),
                                        PrimaryGreen
                                    )
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "امنیت کامل اطلاعات ارزیابی شما",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "ذخیره‌سازی مستقیم روی حافظه گوشی بدون نیاز به اینترنت",
                                        fontSize = 11.5.sp,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "تمام نمرات درسی، غیبت‌ها، تکالیف و مشخصات دانش‌آموزان به صورت محلی در دستگاه شما قرار دارند. با ایجاد نسخه‌های پشتیبان خیالتان از تعویض گوشی یا بروز هرگونه مشکل کاملاً آسوده خواهد بود.",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.92f),
                                lineHeight = 19.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // آمارهای زنده داده‌های فعلی کلاس
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.Black.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    StatMiniBadge(
                                        label = "دانش‌آموز",
                                        value = "${DateUtils.toPersianDigits(state.students.size)}"
                                    )
                                    StatMiniBadge(
                                        label = "ارزیابی ثبت‌شده",
                                        value = "${DateUtils.toPersianDigits(totalEvaluationsCount)}"
                                    )
                                    StatMiniBadge(
                                        label = "جلسه حضورغیاب",
                                        value = "${DateUtils.toPersianDigits(state.attendanceHistory.size)}"
                                    )
                                    StatMiniBadge(
                                        label = "درس کلاسی",
                                        value = "${DateUtils.toPersianDigits(state.subjects.size)}"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ۲. دکمه‌های عملیات اصلی (ذخیره فوری، خروجی به حافظه، بازیابی فایل)
            item {
                Text(
                    text = "عملیات پشتیبان‌گیری و بازیابی",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // دکمه ۱: پشتیبان‌گیری فوری در دستگاه
                    Button(
                        onClick = {
                            val defaultName = "کلاس_${DateUtils.getCurrentShamsiDate().replace('/', '_')}"
                            backupCustomTitle = defaultName
                            showCreateBackupDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("btn_create_backup_instant")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ذخیره در حافظه",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // دکمه ۲: بازیابی از فایل گوشی
                    Button(
                        onClick = {
                            importFileLauncher.launch(arrayOf("application/json", "*/*"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("btn_open_file_restore")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "بازیابی از فایل",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // دکمه ۳: خروجی به پوشه دانلودها یا حافظه خارجی (SAF)
                    OutlinedButton(
                        onClick = {
                            val defaultFileName = "کلاس_${DateUtils.getCurrentShamsiDate().replace('/', '-')}.json"
                            exportFileLauncher.launch(defaultFileName)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_export_to_saf")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "خروجی به دانلودها",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0284C7)
                        )
                    }

                    // دکمه ۴: پشتیبان متنی (کد سریع)
                    OutlinedButton(
                        onClick = {
                            rawTextCode = viewModel.exportDataJson()
                            textCodeMode = "export"
                            showTextCodeDialog = true
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_text_code_backup")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = TeacherTeal,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "پشتیبان متنی",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TeacherTeal
                        )
                    }
                }
            }

            // ۳. سربرگ نسخه‌های ذخیره شده روی دستگاه
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نسخه‌های پشتیبان موجود در دستگاه",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = PrimaryGreen.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "${DateUtils.toPersianDigits(localBackups.size)} نسخه",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // ۴. لیست نسخه‌های ذخیره شده
            if (localBackups.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudSync,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "هنوز نسخه‌ای در حافظه دستگاه ایجاد نشده است",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "با زدن دکمه «ذخیره در حافظه»، نسخه کاملی از تمام ارزشیابی‌ها، حضور و غیاب و اطلاعات دانش‌آموزان روی گوشی شما ثبت می‌شود.",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            } else {
                items(localBackups, key = { it.file.absolutePath }) { backup ->
                    LocalBackupCard(
                        backup = backup,
                        onRestore = { backupToRestore = backup },
                        onShare = { viewModel.shareBackup(context, backup.file) },
                        onDelete = { backupToDelete = backup }
                    )
                }
            }

            // فضای خالی در انتهای لیست
            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // دیالوگ ایجاد نسخه پشتیبان جدید در دستگاه
    if (showCreateBackupDialog) {
        AlertDialog(
            onDismissRequest = { showCreateBackupDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "ذخیره نسخه پشتیبان جدید",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "می‌توانید یک عنوان دلخواه برای این نسخه وارد کنید تا در آینده آن را راحت‌تر پیدا کنید (مثلاً: نمرات ماه آبان):",
                        fontSize = 12.5.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = backupCustomTitle,
                        onValueChange = { backupCustomTitle = it },
                        label = { Text("عنوان نسخه پشتیبان") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_backup_title")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val created = viewModel.createLocalBackup(backupCustomTitle.ifBlank { null })
                        showCreateBackupDialog = false
                        if (created != null) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "نسخه پشتیبان با موفقیت در دستگاه ذخیره شد.",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در ذخیره‌سازی نسخه پشتیبان!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("ذخیره در دستگاه", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateBackupDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ تایید بازگردانی نسخه محلی
    if (backupToRestore != null) {
        val target = backupToRestore!!
        AlertDialog(
            onDismissRequest = { backupToRestore = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "آیا از بازگردانی این نسخه اطمینان دارید؟",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "با تایید این مرحله، اطلاعات فعلی کلاس با نسخه انتخاب شده جایگزین خواهند شد:",
                        fontSize = 12.5.sp,
                        color = TextPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = target.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF92400E)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تاریخ ثبت: ${target.dateShamsi} ساعت ${target.time}",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "تعداد دانش‌آموزان: ${DateUtils.toPersianDigits(target.studentsCount)} نفر",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "تعداد کل ارزیابی‌ها: ${DateUtils.toPersianDigits(target.evaluationsCount)} مورد",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "جلسات حضور و غیاب: ${DateUtils.toPersianDigits(target.attendanceDaysCount)} روز",
                                fontSize = 11.5.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                    }

                    Text(
                        text = "💡 جهت اطمینان و جلوگیری از دست رفتن داده‌ها، قبل از انجام بازگردانی یک نسخه پشتیبان اضطراری از وضعیت فعلی کلاس به طور خودکار ثبت می‌شود.",
                        fontSize = 11.sp,
                        color = PrimaryGreenDark,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = target.file
                        backupToRestore = null
                        val success = viewModel.restoreFromLocalBackup(file)
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "اطلاعات کلاس با موفقیت بازگردانی شد.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در بازگردانی اطلاعات!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بله، بازگردانی شود", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { backupToRestore = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ تایید بازگردانی از فایل خارجی انتخابی (SAF)
    if (pendingRestoreUri != null && pendingRestoreSummary != null) {
        val uri = pendingRestoreUri!!
        val summary = pendingRestoreSummary!!

        AlertDialog(
            onDismissRequest = {
                pendingRestoreUri = null
                pendingRestoreSummary = null
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.FileUpload,
                    contentDescription = null,
                    tint = SkyBlue,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "بازگردانی فایل انتخابی",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "مشخصات فایل انتخاب شده جهت بازگردانی:",
                        fontSize = 12.5.sp,
                        color = TextPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SkyBlue.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, SkyBlue.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "معلم: ${summary.teacherName.ifBlank { "ثبت‌نشده" }} ${if (summary.schoolName.isNotBlank()) "- ${summary.schoolName}" else ""}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SkyBlue
                            )
                            if (summary.dateShamsi.isNotBlank()) {
                                Text(
                                    text = "تاریخ فایل: ${DateUtils.toPersianDigits(summary.dateShamsi)}",
                                    fontSize = 11.5.sp,
                                    color = TextSecondary
                                )
                            }
                            Text(
                                text = "تعداد دانش‌آموزان: ${DateUtils.toPersianDigits(summary.studentsCount)} نفر",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "تعداد کل ارزیابی‌ها: ${DateUtils.toPersianDigits(summary.evaluationsCount)} مورد",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "جلسات حضور و غیاب: ${DateUtils.toPersianDigits(summary.attendanceDaysCount)} روز",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Text(
                        text = "آیا مایلید این فایل در کلاس بارگذاری شود؟",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.importBackupFromUri(uri)
                        pendingRestoreUri = null
                        pendingRestoreSummary = null
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(
                                context,
                                "اطلاعات فایل با موفقیت بازگردانی شد.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "خطا در خواندن و اعمال فایل!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("تایید و بازگردانی", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingRestoreUri = null
                        pendingRestoreSummary = null
                    }
                ) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ حذف نسخه
    if (backupToDelete != null) {
        val target = backupToDelete!!
        AlertDialog(
            onDismissRequest = { backupToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = AbsentRed,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = { Text("حذف نسخه پشتیبان", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "آیا از حذف نسخه «${target.title}» از حافظه گوشی اطمینان دارید؟",
                    fontSize = 13.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = target.file
                        backupToDelete = null
                        val success = viewModel.deleteLocalBackup(file)
                        if (success) {
                            refreshBackupsList()
                            Toast.makeText(context, "نسخه حذف گردید.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AbsentRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { backupToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ کد پشتیبان متنی (کپی یا پیست سریع)
    if (showTextCodeDialog) {
        AlertDialog(
            onDismissRequest = { showTextCodeDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (textCodeMode == "export") "کد متنی پشتیبان" else "ورود کد بازگردانی",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Row {
                        TextButton(
                            onClick = {
                                textCodeMode = if (textCodeMode == "export") "import" else "export"
                                if (textCodeMode == "export") rawTextCode = viewModel.exportDataJson()
                                else rawTextCode = ""
                            }
                        ) {
                            Text(
                                text = if (textCodeMode == "export") "حالت ورود کد" else "حالت کپی کد",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (textCodeMode == "export")
                            "این متن ساختار کامل اطلاعات کلاس شماست. می‌توانید آن را کپی کرده و در پیام‌رسان‌ها یا یادداشت‌های شخصی ذخیره کنید:"
                        else
                            "کد پشتیبان کپی‌شده را در کادر زیر جای‌گذاری کرده و دکمه بازگردانی را بزنید:",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 17.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (textCodeMode == "export") {
                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 160.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = rawTextCode,
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF334155)
                                )
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = rawTextCode,
                            onValueChange = { rawTextCode = it },
                            placeholder = { Text("کد متنی را اینجا جای‌گذاری کنید...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            maxLines = 6
                        )
                    }
                }
            },
            confirmButton = {
                if (textCodeMode == "export") {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Class Backup Code", rawTextCode)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "کد پشتیبان در حافظه کپی شد.", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کپی کد", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            if (rawTextCode.isNotBlank()) {
                                val success = viewModel.importDataJson(rawTextCode.trim())
                                if (success) {
                                    refreshBackupsList()
                                    Toast.makeText(context, "اطلاعات با موفقیت بازیابی شد.", Toast.LENGTH_LONG).show()
                                    showTextCodeDialog = false
                                } else {
                                    Toast.makeText(context, "کد وارد شده معتبر نیست!", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("اعمال و بازگردانی", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showTextCodeDialog = false }) {
                    Text("بستن")
                }
            }
        )
    }
}

@Composable
fun LocalBackupCard(
    backup: LocalBackupFile,
    onRestore: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("backup_item_${backup.file.name}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (backup.isAutoBackup) Color(0xFFF0FDF4) else Color.White
        ),
        border = BorderStroke(
            1.dp,
            if (backup.isAutoBackup) PrimaryGreen.copy(alpha = 0.35f) else BorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (backup.isAutoBackup) PrimaryGreen.copy(alpha = 0.15f)
                                else SkyBlue.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (backup.isAutoBackup) Icons.Default.History else Icons.Default.SettingsBackupRestore,
                            contentDescription = null,
                            tint = if (backup.isAutoBackup) PrimaryGreenDark else SkyBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = backup.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            if (backup.isAutoBackup) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = PrimaryGreen.copy(alpha = 0.18f)
                                ) {
                                    Text(
                                        text = "خودکار",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${backup.dateShamsi} - ساعت ${backup.time} (${backup.sizeFormatted})",
                            fontSize = 11.5.sp,
                            color = TextSecondary
                        )
                    }
                }

                Row {
                    // دکمه اشتراک‌گذاری
                    IconButton(onClick = onShare, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "اشتراک‌گذاری",
                            tint = SkyBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // دکمه حذف
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف نسخه",
                            tint = AbsentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // چیپ‌های خلاصه اطلاعات درون فایل
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.studentsCount)} دانش‌آموز",
                    color = PrimaryGreen
                )
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.evaluationsCount)} ارزیابی",
                    color = EvaluationOrange,
                    isBold = true
                )
                BackupChip(
                    text = "${DateUtils.toPersianDigits(backup.attendanceDaysCount)} جلسه غیبت",
                    color = MeetingPurple
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // دکمه بازگردانی این نسخه
            Button(
                onClick = onRestore,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "بازیابی این نسخه در کلاس",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun BackupChip(text: String, color: Color, isBold: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Text(
            text = text,
            fontSize = 10.5.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun StatMiniBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color.White.copy(alpha = 0.8f)
        )
    }
}
