package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
    darkColorScheme(
        primary = PrimaryGreen,
        onPrimary = Color.White,
        primaryContainer = PrimaryGreenDark,
        onPrimaryContainer = PrimaryGreenLight,
        secondary = AmberSecondary,
        background = Color(0xFF121413),
        surface = Color(0xFF1A1C1B),
        onBackground = Color(0xFFE2E3E0),
        onSurface = Color(0xFFE2E3E0),
    )

private val LightColorScheme =
    lightColorScheme(
        primary = PrimaryGreen,
        onPrimary = Color.White,
        primaryContainer = PrimaryGreenLight,
        onPrimaryContainer = PrimaryGreenDark,
        secondary = AmberSecondary,
        onSecondary = Color(0xFF2C1E00),
        secondaryContainer = AmberSecondaryLight,
        onSecondaryContainer = Color(0xFF5E4200),
        tertiary = SkyBlue,
        background = BackgroundLight,
        surface = SurfaceLight,
        onBackground = TextPrimary,
        onSurface = TextPrimary,
        outline = BorderLight,
        error = AbsentRed,
        onError = Color.White,
        errorContainer = AbsentRedLight,
        onErrorContainer = AbsentRed,
    )

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme =
        when {
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            }
            darkTheme -> DarkColorScheme
            else -> LightColorScheme
        }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
