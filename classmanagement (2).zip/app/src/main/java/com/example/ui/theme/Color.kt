package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF00A86B)
val PrimaryGreenDark = Color(0xFF00794D)
val PrimaryGreenLight = Color(0xFFE0F5EB)

val AmberSecondary = Color(0xFFFFB703)
val AmberSecondaryLight = Color(0xFFFFF3D4)

val SkyBlue = Color(0xFF0284C7)
val SkyBlueLight = Color(0xFFE0F2FE)

val TeacherTeal = Color(0xFF0D9488)
val TeacherTealLight = Color(0xFFCCFBF1)

val MeetingPurple = Color(0xFF8B5CF6)
val MeetingPurpleLight = Color(0xFFF3E8FF)

val EvaluationOrange = Color(0xFFF97316)
val EvaluationOrangeLight = Color(0xFFFFEDD5)

val AbsentRed = Color(0xFFEF4444)
val AbsentRedLight = Color(0xFFFEE2E2)

val BackgroundLight = Color(0xFFF4F7F6)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
