package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ScoreBadge(score: String) {
    val (bgColor, textColor) = when (score) {
        "خیلی خوب" -> Color(0xFFDCFCE7) to Color(0xFF166534)
        "خوب" -> Color(0xFFDBEAFE) to Color(0xFF1E40AF)
        "قابل قبول" -> Color(0xFFFEF3C7) to Color(0xFF92400E)
        "نیاز به تلاش" -> Color(0xFFFEE2E2) to Color(0xFF991B1B)
        else -> Color(0xFFF3F4F6) to Color(0xFF374151)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = score,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun AttendanceBadge(status: String) {
    val (bgColor, textColor) = when (status) {
        "حاضر" -> Color(0xFFDCFCE7) to Color(0xFF166534)
        "غایب" -> Color(0xFFFEE2E2) to Color(0xFFB91C1C)
        "غیرموجه" -> Color(0xFFFFEDD5) to Color(0xFFC2410C)
        "موجه" -> Color(0xFFE0F2FE) to Color(0xFF0369A1)
        else -> Color(0xFFF3F4F6) to Color(0xFF374151)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
