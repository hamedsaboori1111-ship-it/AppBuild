package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Evaluation
import com.example.model.Student
import com.example.model.SubjectItem
import com.example.ui.theme.*

data class EvaluationListItem(
    val studentId: Long,
    val studentName: String,
    val evaluation: Evaluation
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluationScreen(
    students: List<Student>,
    subjects: List<SubjectItem>,
    currentDate: String,
    onBack: () -> Unit,
    onAddEvaluation: (Long, String, String, String, String) -> Unit,
    onDeleteEvaluation: (Long, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val activeSubjects = remember(subjects) { subjects.filter { it.enabled } }

    // حالت‌های فیلتر
    var selectedTypeFilter by remember { mutableStateOf("همه") } // همه، کلاسی، ماهانه، سالانه
    var selectedSubjectFilter by remember { mutableStateOf("همه دروس") }
    var selectedSubjectForGrading by remember {
        mutableStateOf(activeSubjects.firstOrNull()?.name ?: "ریاضی")
    }
    var gradingType by remember { mutableStateOf("کلاسی") } // نوع مورد استفاده برای ثبت سریع نمره
    var activeTab by remember { mutableIntStateOf(0) } // 0: لیست ارزشیابی‌ها، 1: ثبت نمره دانش‌آموزان
    var searchQuery by remember { mutableStateOf("") }
    var subjectDropdownExpanded by remember { mutableStateOf(false) }
    var gradingSubjectDropdownExpanded by remember { mutableStateOf(false) }

    // دیالوگ تأیید حذف ارزشیابی
    var itemToDelete by remember { mutableStateOf<EvaluationListItem?>(null) }

    val typeOptions = listOf("همه", "کلاسی", "ماهانه", "سالانه")
    val scoreOptions = listOf("خیلی خوب", "خوب", "قابل قبول", "نیاز به تلاش")

    // استخراج لیست مسطح تمام ارزشیابی‌ها
    val allEvaluationItems = remember(students) {
        students.flatMap { student ->
            student.evaluations.map { eval ->
                EvaluationListItem(
                    studentId = student.id,
                    studentName = student.name,
                    evaluation = eval
                )
            }
        }.sortedByDescending { it.evaluation.date }
    }

    // شمارش تعداد ارزشیابی‌ها برای هر نوع
    val totalCount = allEvaluationItems.size
    val classCount = allEvaluationItems.count { it.evaluation.type == "کلاسی" }
    val monthlyCount = allEvaluationItems.count { it.evaluation.type == "ماهانه" }
    val yearlyCount = allEvaluationItems.count { it.evaluation.type == "سالانه" }

    // فیلتر کردن لیست ارزشیابی‌ها بر اساس نوع، درس و جستجو
    val filteredEvaluations = remember(allEvaluationItems, selectedTypeFilter, selectedSubjectFilter, searchQuery) {
        allEvaluationItems.filter { item ->
            val matchType = (selectedTypeFilter == "همه" || item.evaluation.type == selectedTypeFilter)
            val matchSubject = (selectedSubjectFilter == "همه دروس" || item.evaluation.subject == selectedSubjectFilter)
            val matchQuery = searchQuery.isBlank() || item.studentName.contains(searchQuery.trim(), ignoreCase = true)
            matchType && matchSubject && matchQuery
        }
    }

    // آمار نمرات فیلتر شده
    val countVeryGood = filteredEvaluations.count { it.evaluation.score == "خیلی خوب" }
    val countGood = filteredEvaluations.count { it.evaluation.score == "خوب" }
    val countAcceptable = filteredEvaluations.count { it.evaluation.score == "قابل قبول" }
    val countNeedsWork = filteredEvaluations.count { it.evaluation.score == "نیاز به تلاش" }

    // دیالوگ تأیید حذف
    itemToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("حذف ارزشیابی", fontWeight = FontWeight.Bold) },
            text = {
                Text("آیا از حذف ارزشیابی «${item.evaluation.subject} (${item.evaluation.type}) - ${item.evaluation.score}» مربوط به دانش‌آموز «${item.studentName}» اطمینان دارید؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteEvaluation(item.studentId, item.evaluation.id)
                        Toast.makeText(context, "ارزشیابی حذف شد.", Toast.LENGTH_SHORT).show()
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف شود", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("ارزشیابی و عملکرد تحصیلی", fontWeight = FontWeight.Bold, color = Color.White)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EvaluationOrange)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // ۱. تب‌های نمای صفحه: لیست ارزشیابی‌ها | ثبت نمره دانش‌آموزان
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.White,
                contentColor = EvaluationOrange,
                divider = { HorizontalDivider(color = BorderLight) }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "لیست ارزشیابی‌ها (${filteredEvaluations.size})",
                                fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ثبت نمره دانش‌آموزان",
                                fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
            }

            // ۲. نوار ابزار فیلتر بر اساس نوع (کلاسی، ماهانه، سالانه) و درس
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // سطر اول فیلتر نوع ارزشیابی (همه، کلاسی، ماهانه، سالانه)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نوع ارزشیابی:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.padding(start = 2.dp, end = 6.dp)
                        )

                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            typeOptions.forEach { type ->
                                val count = when (type) {
                                    "همه" -> totalCount
                                    "کلاسی" -> classCount
                                    "ماهانه" -> monthlyCount
                                    "سالانه" -> yearlyCount
                                    else -> 0
                                }
                                val isSelected = selectedTypeFilter == type
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedTypeFilter = type
                                        if (type != "همه") {
                                            gradingType = type
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = "$type ($count)",
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = when (type) {
                                            "کلاسی" -> SkyBlue
                                            "ماهانه" -> MeetingPurple
                                            "سالانه" -> PrimaryGreenDark
                                            else -> EvaluationOrange
                                        },
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // سطر دوم: انتخاب درس برای فیلتر و جستجو
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // منوی کشویی درس فیلتر
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(
                                onClick = { subjectDropdownExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f, fill = false)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MenuBook,
                                            contentDescription = null,
                                            tint = EvaluationOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = selectedSubjectFilter,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = subjectDropdownExpanded,
                                onDismissRequest = { subjectDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("همه دروس", fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        selectedSubjectFilter = "همه دروس"
                                        subjectDropdownExpanded = false
                                    }
                                )
                                activeSubjects.forEach { sub ->
                                    DropdownMenuItem(
                                        text = { Text(sub.name) },
                                        onClick = {
                                            selectedSubjectFilter = sub.name
                                            subjectDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // فیلد جستجوی نام دانش‌آموز در لیست
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("جستجوی نام...", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1.1f)
                                .height(46.dp),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "جستجو",
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "پاک کردن",
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        )
                    }
                }
            }

            // ۳. محتوای هر تب بر اساس انتخاب معلم
            if (activeTab == 0) {
                // =============== تب ۱: لیست ارزشیابی‌های فیلتر شده ===============
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // آمار خلاصه نتایج فیلتر
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "یافته‌ها: ${filteredEvaluations.size} مورد",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimary
                                    )

                                    Text(
                                        text = "فیلتر نوع: $selectedTypeFilter",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // چیپ‌های آمار کیفی نمرات در فیلتر انتخابی
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ScoreStatChip(title = "خیلی خوب", count = countVeryGood, color = Color(0xFF166534), bgColor = Color(0xFFDCFCE7), modifier = Modifier.weight(1f))
                                    ScoreStatChip(title = "خوب", count = countGood, color = Color(0xFF1E40AF), bgColor = Color(0xFFDBEAFE), modifier = Modifier.weight(1f))
                                    ScoreStatChip(title = "قابل قبول", count = countAcceptable, color = Color(0xFF92400E), bgColor = Color(0xFFFEF3C7), modifier = Modifier.weight(1f))
                                    ScoreStatChip(title = "تلاش", count = countNeedsWork, color = Color(0xFF991B1B), bgColor = Color(0xFFFEE2E2), modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    if (filteredEvaluations.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SearchOff,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "هیچ ارزشیابی با فیلتر انتخابی یافت نشد.",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "می‌توانید فیلتر نوع یا درس را تغییر دهید، یا از تب «ثبت نمره» ارزشیابی جدید ثبت نمایید.",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    } else {
                        items(filteredEvaluations, key = { "${it.studentId}_${it.evaluation.id}" }) { item ->
                            EvaluationCardItem(
                                item = item,
                                onDelete = { itemToDelete = item }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            } else {
                // =============== تب ۲: ثبت نمره دانش‌آموزان ===============
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // کادر تنظیمات ثبت نمره (درس جاری و نوع ارزشیابی)
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "تنظیمات ثبت نمره سریع",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // انتخاب درس جهت ثبت
                                    Box(modifier = Modifier.weight(1.2f)) {
                                        OutlinedCard(
                                            onClick = { gradingSubjectDropdownExpanded = true },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "درس: $selectedSubjectForGrading",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        DropdownMenu(
                                            expanded = gradingSubjectDropdownExpanded,
                                            onDismissRequest = { gradingSubjectDropdownExpanded = false }
                                        ) {
                                            activeSubjects.forEach { sub ->
                                                DropdownMenuItem(
                                                    text = { Text(sub.name) },
                                                    onClick = {
                                                        selectedSubjectForGrading = sub.name
                                                        gradingSubjectDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // انتخاب نوع ثبت نمره (کلاسی، ماهانه، سالانه)
                                    var gradingTypeMenuExpanded by remember { mutableStateOf(false) }
                                    Box(modifier = Modifier.weight(1f)) {
                                        OutlinedCard(
                                            onClick = { gradingTypeMenuExpanded = true },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "نوع: $gradingType",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when (gradingType) {
                                                        "کلاسی" -> SkyBlue
                                                        "ماهانه" -> MeetingPurple
                                                        else -> PrimaryGreenDark
                                                    }
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        DropdownMenu(
                                            expanded = gradingTypeMenuExpanded,
                                            onDismissRequest = { gradingTypeMenuExpanded = false }
                                        ) {
                                            listOf("کلاسی", "ماهانه", "سالانه").forEach { t ->
                                                DropdownMenuItem(
                                                    text = { Text(t) },
                                                    onClick = {
                                                        gradingType = t
                                                        gradingTypeMenuExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "فهرست دانش‌آموزان (${students.size} نفر)",
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "تاریخ ثبت: $currentDate",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    items(students, key = { it.id }) { student ->
                        StudentEvaluationCard(
                            student = student,
                            selectedSubject = selectedSubjectForGrading,
                            evalType = gradingType,
                            selectedTypeFilter = selectedTypeFilter,
                            currentDate = currentDate,
                            scoreOptions = scoreOptions,
                            onScoreSelected = { score ->
                                onAddEvaluation(student.id, selectedSubjectForGrading, gradingType, score, currentDate)
                                Toast.makeText(
                                    context,
                                    "نمره «$score» برای ${student.name} در درس «$selectedSubjectForGrading» ($gradingType) ثبت شد.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onDeleteEvaluation = { evalId ->
                                onDeleteEvaluation(student.id, evalId)
                            }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun EvaluationCardItem(
    item: EvaluationListItem,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // آواتار دانش‌آموز
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(EvaluationOrange.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.studentName.take(1),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = EvaluationOrange
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = item.studentName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.evaluation.subject,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Text(
                            text = " • ",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = item.evaluation.date,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // برچسب نوع ارزشیابی (کلاسی، ماهانه، سالانه)
                EvaluationTypeBadge(type = item.evaluation.type)

                // برچسب نمره
                ScoreBadge(score = item.evaluation.score)

                // دکمه حذف ارزشیابی
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف ارزشیابی",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EvaluationTypeBadge(type: String) {
    val (bgColor, textColor, borderColor) = when (type) {
        "کلاسی" -> Triple(SkyBlue.copy(alpha = 0.12f), SkyBlue, SkyBlue.copy(alpha = 0.35f))
        "ماهانه" -> Triple(MeetingPurple.copy(alpha = 0.12f), MeetingPurple, MeetingPurple.copy(alpha = 0.35f))
        "سالانه" -> Triple(PrimaryGreenDark.copy(alpha = 0.12f), PrimaryGreenDark, PrimaryGreenDark.copy(alpha = 0.35f))
        else -> Triple(Color(0xFFF3F4F6), TextSecondary, Color(0xFFE5E7EB))
    }
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = type,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun ScoreStatChip(
    title: String,
    count: Int,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = color
            )
            Text(
                text = "$count",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
fun StudentEvaluationCard(
    student: Student,
    selectedSubject: String,
    evalType: String,
    selectedTypeFilter: String,
    currentDate: String,
    scoreOptions: List<String>,
    onScoreSelected: (String) -> Unit,
    onDeleteEvaluation: (String) -> Unit
) {
    var showHistory by remember { mutableStateOf(false) }
    var scoreMenuExpanded by remember { mutableStateOf(false) }

    // فیلتر کردن سوابق ارزشیابی‌های دانش‌آموز بر اساس فیلتر نوع
    val filteredStudentEvaluations = remember(student.evaluations, selectedTypeFilter, selectedSubject) {
        student.evaluations.filter { ev ->
            val matchType = (selectedTypeFilter == "همه" || ev.type == selectedTypeFilter)
            matchType
        }
    }

    // آخرین نمره ثبت‌شده مطابق درس و نوع انتخابی
    val lastEval = student.evaluations.lastOrNull {
        it.subject == selectedSubject && (selectedTypeFilter == "همه" || it.type == selectedTypeFilter)
    } ?: student.evaluations.lastOrNull { selectedTypeFilter == "همه" || it.type == selectedTypeFilter }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (lastEval != null) {
                            "آخرین نمره (${lastEval.subject}): ${lastEval.score} [${lastEval.type}]"
                        } else {
                            if (selectedTypeFilter != "همه") "هنوز نمره «$selectedTypeFilter» ثبت نشده است"
                            else "هنوز نمره‌ای ثبت نشده است"
                        },
                        fontSize = 11.sp,
                        color = if (lastEval != null) TextPrimary else TextSecondary
                    )
                }

                // دکمه انتخاب سریع نمره
                Box {
                    Button(
                        onClick = { scoreMenuExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EvaluationOrange),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("ثبت نمره", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = scoreMenuExpanded,
                        onDismissRequest = { scoreMenuExpanded = false }
                    ) {
                        scoreOptions.forEach { score ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(score)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        ScoreBadge(score = score)
                                    }
                                },
                                onClick = {
                                    scoreMenuExpanded = false
                                    onScoreSelected(score)
                                }
                            )
                        }
                    }
                }
            }

            // مشاهده تاریخچه ارزیابی‌های فیلتر شده دانش‌آموز
            if (filteredStudentEvaluations.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showHistory = !showHistory }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showHistory) {
                            "پنهان‌سازی سوابق (${filteredStudentEvaluations.size})"
                        } else {
                            "سوابق ارزیابی${if (selectedTypeFilter != "همه") " «$selectedTypeFilter»" else ""} (${filteredStudentEvaluations.size} مورد)"
                        },
                        fontSize = 11.sp,
                        color = SkyBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = if (showHistory) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = SkyBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }

                AnimatedVisibility(visible = showHistory) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        filteredStudentEvaluations.takeLast(6).reversed().forEach { ev ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(BackgroundLight, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    EvaluationTypeBadge(type = ev.type)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${ev.subject} - ${ev.date}",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ScoreBadge(score = ev.score)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { onDeleteEvaluation(ev.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "حذف",
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
