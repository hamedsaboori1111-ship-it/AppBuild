package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.DailyAttendance
import com.example.model.Student
import com.example.model.StudentAttendanceRecord
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    students: List<Student>,
    currentDate: String = "۱۴۰۳/۰۷/۱۵",
    attendanceHistory: List<DailyAttendance> = emptyList(),
    onBack: () -> Unit,
    onStatusChange: (Long, String) -> Unit,
    onMarkAllPresent: () -> Unit,
    onAddStudent: (String, String, String) -> Unit = { _, _, _ -> },
    onSaveStudent: (Student) -> Boolean = { true },
    onUpdateStudent: (Student) -> Boolean = { true },
    onDeleteStudent: (Long) -> Unit,
    onUpdateHistoricalAttendance: (String, Long, String) -> Unit = { _, _, _ -> },
    onMarkAllPresentForDate: (String) -> Unit = {},
    onAddHistoricalDate: (String) -> Unit = {},
    onDeleteHistoricalDate: (String) -> Unit = {}
) {
    val context = LocalContext.current

    // تب‌ها: ۰ = حضور و غیاب امروز، ۱ = بررسی و ویرایش روزهای قبل
    var activeTab by remember { mutableIntStateOf(0) }

    // وضعیت‌های مدیریت اطلاعات دانش‌آموز (افزودن / ویرایش / مشاهده)
    var showStudentFormDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var viewingStudent by remember { mutableStateOf<Student?>(null) }

    // وضعیت‌های دیالوگ تأیید حذف و تأیید ویرایش با نام دانش‌آموز
    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var studentToConfirmEdit by remember { mutableStateOf<Student?>(null) }

    val statusOptions = listOf("حاضر", "غایب", "غیرموجه", "موجه")

    // --- حالت‌های تب بررسی روزهای قبل ---
    val availableDates = remember(attendanceHistory, currentDate) {
        val dates = attendanceHistory.map { it.date }.toMutableSet()
        if (currentDate.isNotBlank()) dates.add(currentDate)
        dates.toList().sortedDescending()
    }

    var selectedPastDate by remember(availableDates) {
        mutableStateOf(
            availableDates.firstOrNull { it != currentDate } ?: availableDates.firstOrNull() ?: currentDate
        )
    }

    // وضعیت قفل ویرایش برای روزهای قبل (اطمینان از تغییر)
    var isChangeConfirmed by remember { mutableStateOf(false) }
    var showConfirmChangeDialog by remember { mutableStateOf(false) }

    // دیالوگ افزودن تاریخ دستی جدید
    var showAddDateDialog by remember { mutableStateOf(false) }
    var newCustomDateInput by remember { mutableStateOf("") }

    // دیالوگ تأیید حذف رکورد تاریخ
    var showDeleteDateDialog by remember { mutableStateOf(false) }

    // آمار امروز
    val todayPresentCount = students.count { it.status == "حاضر" }
    val todayAbsentCount = students.count { it.status == "غایب" || it.status == "غیرموجه" }
    val todayExcusedCount = students.count { it.status == "موجه" }

    // رکورد تاریخ انتخابی روزهای قبل
    val selectedDateRecord = remember(attendanceHistory, selectedPastDate) {
        attendanceHistory.find { it.date == selectedPastDate }
    }

    val studentStatusMapForSelectedDate = remember(students, selectedDateRecord, selectedPastDate, currentDate) {
        students.associate { student ->
            val statusInRecord = selectedDateRecord?.records?.find { it.studentId == student.id }?.status
            val finalStatus = if (statusInRecord != null) {
                statusInRecord
            } else if (selectedPastDate == currentDate) {
                student.status
            } else {
                "حاضر"
            }
            student.id to finalStatus
        }
    }

    val pastPresentCount = studentStatusMapForSelectedDate.values.count { it == "حاضر" }
    val pastAbsentCount = studentStatusMapForSelectedDate.values.count { it == "غایب" || it == "غیرموجه" }
    val pastExcusedCount = studentStatusMapForSelectedDate.values.count { it == "موجه" }

    val pastAbsentStudents = remember(students, studentStatusMapForSelectedDate) {
        students.filter { student ->
            val st = studentStatusMapForSelectedDate[student.id]
            st == "غایب" || st == "غیرموجه" || st == "موجه"
        }
    }

    LaunchedEffect(selectedPastDate) {
        isChangeConfirmed = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("دفتر حضور و غیاب کلاس", fontWeight = FontWeight.Bold, color = Color.White)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (activeTab == 0) {
                        TextButton(
                            onClick = {
                                onMarkAllPresent()
                                Toast.makeText(context, "همه دانش‌آموزان حاضر ثبت شدند.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حاضر کردن همه", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        floatingActionButton = {
            if (activeTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingStudent = null
                        showStudentFormDialog = true
                    },
                    icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                    text = { Text("افزودن دانش‌آموز", fontWeight = FontWeight.Bold) },
                    containerColor = PrimaryGreen,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_student_fab")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // ۱. تب‌های بالایی
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.White,
                contentColor = PrimaryGreen,
                divider = { HorizontalDivider(color = BorderLight) }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Today,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "امروز ($currentDate)",
                                fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "بررسی و ویرایش روزهای قبل",
                                fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
            }

            // ۲. محتوای هر تب
            if (activeTab == 0) {
                // ==================== تب ۱: امروز ====================
                Surface(
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatPill(title = "کل دانش‌آموزان", count = "${students.size} نفر", color = TextPrimary)
                        StatPill(title = "حاضرین امروز", count = "$todayPresentCount نفر", color = PrimaryGreenDark)
                        StatPill(title = "غایبین امروز", count = "$todayAbsentCount نفر", color = Color(0xFFD32F2F))
                        if (todayExcusedCount > 0) {
                            StatPill(title = "موجه", count = "$todayExcusedCount نفر", color = Color(0xFF0284C7))
                        }
                    }
                }

                if (students.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("دانش‌آموزی در کلاس ثبت نشده است.", color = TextSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("برای ثبت مشخصات کامل دانش‌آموز جدید روی دکمه زیر کلیک کنید.", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(students, key = { it.id }) { student ->
                            StudentAttendanceCard(
                                student = student,
                                status = student.status,
                                isEditable = true,
                                statusOptions = statusOptions,
                                onStatusSelected = {
                                    onStatusChange(student.id, it)
                                    Toast.makeText(context, "وضعیت ${student.name} به «$it» تغییر کرد.", Toast.LENGTH_SHORT).show()
                                },
                                onClickCard = { viewingStudent = student },
                                onEdit = {
                                    editingStudent = student
                                    showStudentFormDialog = true
                                },
                                onDelete = {
                                    studentToDelete = student
                                }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(76.dp))
                        }
                    }
                }

            } else {
                // ==================== تب ۲: بررسی و ویرایش روزهای قبل ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // ۱. بخش انتخاب تاریخ‌های گذشته
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = PrimaryGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "انتخاب تاریخ جهت بررسی آمار:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TextPrimary
                                        )
                                    }

                                    TextButton(
                                        onClick = {
                                            newCustomDateInput = ""
                                            showAddDateDialog = true
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تاریخ دیگر", fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    availableDates.forEach { dateStr ->
                                        val isSelected = dateStr == selectedPastDate
                                        val rec = attendanceHistory.find { it.date == dateStr }
                                        val absCount = rec?.records?.count { it.status == "غایب" || it.status == "غیرموجه" }
                                            ?: if (dateStr == currentDate) todayAbsentCount else 0

                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { selectedPastDate = dateStr },
                                            label = {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        text = if (dateStr == currentDate) "$dateStr (امروز)" else dateStr,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 12.sp
                                                    )
                                                    Text(
                                                        text = if (absCount > 0) "$absCount غایب" else "کامل حاضر",
                                                        fontSize = 10.sp,
                                                        color = if (isSelected) Color.White.copy(alpha = 0.9f)
                                                        else if (absCount > 0) Color(0xFFDC2626) else PrimaryGreenDark
                                                    )
                                                }
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = PrimaryGreen,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ۲. کارت آمار تحلیلی روز انتخابی
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "آمار حضور و غیاب روز «$selectedPastDate»",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextPrimary
                                    )

                                    if (selectedPastDate != currentDate) {
                                        IconButton(
                                            onClick = { showDeleteDateDialog = true },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف رکورد تاریخ",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ScoreStatChip(
                                        title = "کل دانش‌آموزان",
                                        count = students.size,
                                        color = TextPrimary,
                                        bgColor = Color(0xFFF3F4F6),
                                        modifier = Modifier.weight(1f)
                                    )
                                    ScoreStatChip(
                                        title = "حاضرین",
                                        count = pastPresentCount,
                                        color = Color(0xFF166534),
                                        bgColor = Color(0xFFDCFCE7),
                                        modifier = Modifier.weight(1f)
                                    )
                                    ScoreStatChip(
                                        title = "غایبین",
                                        count = pastAbsentCount,
                                        color = Color(0xFFB91C1C),
                                        bgColor = Color(0xFFFEE2E2),
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (pastExcusedCount > 0) {
                                        ScoreStatChip(
                                            title = "موجه",
                                            count = pastExcusedCount,
                                            color = Color(0xFF0369A1),
                                            bgColor = Color(0xFFE0F2FE),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // باکس نمایش غایبین روز
                                if (pastAbsentStudents.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFFEF2F2),
                                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.PersonOff,
                                                    contentDescription = null,
                                                    tint = Color(0xFFDC2626),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "اسامی غایبین در این روز (${pastAbsentStudents.size} نفر):",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = Color(0xFF991B1B)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                pastAbsentStudents.forEach { st ->
                                                    val stStatus = studentStatusMapForSelectedDate[st.id] ?: "غایب"
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "• ${st.name}",
                                                            fontSize = 12.sp,
                                                            color = Color(0xFF7F1D1D)
                                                        )
                                                        Text(
                                                            text = "($stStatus)",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = when (stStatus) {
                                                                "موجه" -> Color(0xFF0369A1)
                                                                "غیرموجه" -> Color(0xFFC2410C)
                                                                else -> Color(0xFFB91C1C)
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF0FDF4),
                                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = PrimaryGreenDark,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "در این تاریخ کلیه دانش‌آموزان حاضر بوده‌اند.",
                                                fontSize = 12.sp,
                                                color = Color(0xFF166534),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ۳. نوار کنترل امنیتی «اطمینان از تغییر» برای ویرایش روزهای قبل
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isChangeConfirmed) Color(0xFFFFFBEB) else Color(0xFFF8FAFC)
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (isChangeConfirmed) Color(0xFFF59E0B) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isChangeConfirmed) Icons.Default.LockOpen else Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = if (isChangeConfirmed) Color(0xFFD97706) else Color(0xFF64748B),
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = if (isChangeConfirmed) "حالت ویرایش فعال است" else "قفل ویرایش فعال است (حالت امن)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (isChangeConfirmed) Color(0xFF92400E) else TextPrimary
                                            )
                                            Text(
                                                text = if (isChangeConfirmed)
                                                    "می‌توانید وضعیت هر دانش‌آموز را تغییر دهید؛ آمار روز فوراً به‌روز خواهد شد."
                                                else
                                                    "جهت جلوگیری از تغییر ناخواسته آمار روزهای قبل، ویرایش قفل است.",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = if (isChangeConfirmed) Color(0xFFFDE68A) else BorderLight, thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (!isChangeConfirmed) {
                                                showConfirmChangeDialog = true
                                            } else {
                                                isChangeConfirmed = false
                                                Toast.makeText(context, "حالت ویرایش غیرفعال و قفل شد.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Checkbox(
                                            checked = isChangeConfirmed,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    showConfirmChangeDialog = true
                                                } else {
                                                    isChangeConfirmed = false
                                                    Toast.makeText(context, "حالت ویرایش قفل شد.", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = Color(0xFFD97706)
                                            )
                                        )
                                        Text(
                                            text = "اطمینان از تغییر و ویرایش آمار این تاریخ دارم",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isChangeConfirmed) Color(0xFF92400E) else TextPrimary
                                        )
                                    }

                                    if (isChangeConfirmed) {
                                        TextButton(
                                            onClick = {
                                                onMarkAllPresentForDate(selectedPastDate)
                                                Toast.makeText(context, "همه دانش‌آموزان در تاریخ «$selectedPastDate» حاضر شدند.", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.textButtonColors(contentColor = PrimaryGreenDark)
                                        ) {
                                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("حاضر کردن همه", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ۴. فهرست دانش‌آموزان در این تاریخ
                    item {
                        Text(
                            text = "لیست دانش‌آموزان و وضعیت حضور در «$selectedPastDate»:",
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    items(students, key = { it.id }) { student ->
                        val currentRecordedStatus = studentStatusMapForSelectedDate[student.id] ?: "حاضر"

                        StudentAttendanceCard(
                            student = student,
                            status = currentRecordedStatus,
                            isEditable = isChangeConfirmed,
                            statusOptions = statusOptions,
                            onStatusSelected = { newStatus ->
                                onUpdateHistoricalAttendance(selectedPastDate, student.id, newStatus)
                                Toast.makeText(
                                    context,
                                    "وضعیت ${student.name} در تاریخ «$selectedPastDate» به «$newStatus» تغییر یافت و آمار ذخیره شد.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            onClickCard = { viewingStudent = student },
                            onEdit = {
                                editingStudent = student
                                showStudentFormDialog = true
                            },
                            onDelete = {}
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(30.dp))
                    }
                }
            }
        }
    }

    // ==================== دیالوگ‌های تأیید و فرم‌ها ====================

    // ۱. دیالوگ تأیید حذف دانش‌آموز با نام
    studentToDelete?.let { student ->
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأیید حذف دانش‌آموز",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "آیا از حذف دانش‌آموز با نام «${student.name}» مطمئن هستید؟ با حذف دانش‌آموز، کلیه سوابق ارزشیابی و حضور و غیاب وی پاک خواهد شد.",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteStudent(student.id)
                        Toast.makeText(context, "دانش‌آموز «${student.name}» با موفقیت حذف شد.", Toast.LENGTH_SHORT).show()
                        studentToDelete = null
                        if (viewingStudent?.id == student.id) viewingStudent = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("بله، حذف شود", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۲. دیالوگ تأیید ویرایش دانش‌آموز با نام
    studentToConfirmEdit?.let { student ->
        AlertDialog(
            onDismissRequest = { studentToConfirmEdit = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircleOutline,
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأیید ویرایش اطلاعات",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "آیا از ذخیره ویرایش اطلاعات دانش‌آموز با نام «${student.name}» مطمئن هستید؟",
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = onUpdateStudent(student)
                        if (success) {
                            Toast.makeText(context, "اطلاعات دانش‌آموز «${student.name}» با موفقیت ویرایش شد.", Toast.LENGTH_SHORT).show()
                            showStudentFormDialog = false
                            editingStudent = null
                            studentToConfirmEdit = null
                            if (viewingStudent?.id == student.id) viewingStudent = student
                        } else {
                            Toast.makeText(context, "خطا: نام یا شماره شاد تکراری است و نمی‌تواند با دانش‌آموز دیگری یکسان باشد!", Toast.LENGTH_LONG).show()
                            studentToConfirmEdit = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بله، ذخیره شود", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToConfirmEdit = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۳. فرم جامع افزودن / ویرایش دانش‌آموز با تمام فیلدها و عکس
    if (showStudentFormDialog) {
        StudentFormDialog(
            initialStudent = editingStudent,
            existingStudents = students,
            onDismiss = {
                showStudentFormDialog = false
                editingStudent = null
            },
            onRequestSave = { newStudentData ->
                if (editingStudent != null) {
                    // قبل از ویرایش، دیالوگ تأیید نام را نشان بده
                    studentToConfirmEdit = newStudentData
                } else {
                    // افزودن دانش‌آموز جدید
                    val success = onSaveStudent(newStudentData)
                    if (success) {
                        Toast.makeText(context, "دانش‌آموز «${newStudentData.name}» با موفقیت ثبت شد.", Toast.LENGTH_SHORT).show()
                        showStudentFormDialog = false
                        editingStudent = null
                    } else {
                        Toast.makeText(context, "خطا: دانش‌آموزی با این نام یا شماره شاد قبلاً ثبت شده است و امکان ثبت تکراری وجود ندارد!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // ۴. دیالوگ شناسنامه و پرونده کامل دانش‌آموز
    viewingStudent?.let { student ->
        StudentProfileDetailDialog(
            student = student,
            onDismiss = { viewingStudent = null },
            onEdit = {
                viewingStudent = null
                editingStudent = student
                showStudentFormDialog = true
            },
            onDelete = {
                studentToDelete = student
            }
        )
    }

    // ۵. دیالوگ تأیید «اطمینان از تغییر» برای سوابق روزهای قبل
    if (showConfirmChangeDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmChangeDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "اطمینان از تغییر آمار تاریخ $selectedPastDate",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "شما در حال فعال‌سازی ویرایش سوابق حضور و غیاب گذشته هستید. هرگونه تغییر در وضعیت حاضرین و غایبین، آمار و نمودارهای روزهای قبل را اصلاح خواهد کرد.\n\nآیا از ادامه و ثبت تغییرات اطمینان دارید؟",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        isChangeConfirmed = true
                        showConfirmChangeDialog = false
                        Toast.makeText(context, "حالت ویرایش فعال شد. تغییرات مورد نظر خود را اعمال کنید.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                ) {
                    Text("بله، اطمینان دارم", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmChangeDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۶. دیالوگ افزودن تاریخ دستی جدید
    if (showAddDateDialog) {
        AlertDialog(
            onDismissRequest = { showAddDateDialog = false },
            title = { Text("ثبت یا بررسی تاریخ جدید", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "تاریخ شمسی مورد نظر را وارد نمایید (مثال: ۱۴۰۳/۰۷/۰۸):",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = newCustomDateInput,
                        onValueChange = { newCustomDateInput = it },
                        placeholder = { Text("۱۴۰۳/۰۷/...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCustomDateInput.isNotBlank()) {
                            val trimmedDate = newCustomDateInput.trim()
                            onAddHistoricalDate(trimmedDate)
                            selectedPastDate = trimmedDate
                            showAddDateDialog = false
                            Toast.makeText(context, "تاریخ «$trimmedDate» به فهرست اضافه شد.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("افزودن و مشاهده")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDateDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // ۷. دیالوگ تأیید حذف رکورد تاریخ انتخابی
    if (showDeleteDateDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDateDialog = false },
            title = { Text("حذف رکورد تاریخ", fontWeight = FontWeight.Bold) },
            text = {
                Text("آیا از حذف کامل سوابق حضور و غیاب تاریخ «$selectedPastDate» اطمینان دارید؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteHistoricalDate(selectedPastDate)
                        Toast.makeText(context, "رکورد تاریخ «$selectedPastDate» حذف شد.", Toast.LENGTH_SHORT).show()
                        showDeleteDateDialog = false
                        selectedPastDate = availableDates.firstOrNull { it != selectedPastDate } ?: currentDate
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف شود", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDateDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}

/**
 * کارت دانش‌آموز با نمایش آواتار / عکس، نام، مشخصات و وضعیت حضور
 */
@Composable
fun StudentAttendanceCard(
    student: Student,
    status: String,
    isEditable: Boolean,
    statusOptions: List<String>,
    onStatusSelected: (String) -> Unit,
    onClickCard: () -> Unit = {},
    onEdit: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClickCard() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // نمایش عکس دانش‌آموز یا آیکون با اولین حرف نام
                if (student.photoUri.isNotBlank()) {
                    AsyncImage(
                        model = student.photoUri,
                        contentDescription = "عکس ${student.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE5E7EB))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PrimaryGreen.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.name.take(1),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = PrimaryGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = student.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "شاد: ${student.shad.ifBlank { "—" }}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        if (student.fatherName.isNotBlank()) {
                            Text(
                                text = " • پدر: ${student.fatherName}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // بخش وضعیت حضور و دکمه‌های عملیات
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isEditable) {
                    Box {
                        Surface(
                            onClick = { expanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when (status) {
                                "حاضر" -> Color(0xFFDCFCE7)
                                "غایب" -> Color(0xFFFEE2E2)
                                "غیرموجه" -> Color(0xFFFFEDD5)
                                else -> Color(0xFFE0F2FE)
                            },
                            border = BorderStroke(
                                1.dp,
                                when (status) {
                                    "حاضر" -> Color(0xFF86EFAC)
                                    "غایب" -> Color(0xFFFCA5A5)
                                    "غیرموجه" -> Color(0xFFFDBA74)
                                    else -> Color(0xFFBAE6FD)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = status,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = when (status) {
                                        "حاضر" -> Color(0xFF166534)
                                        "غایب" -> Color(0xFFB91C1C)
                                        "غیرموجه" -> Color(0xFFC2410C)
                                        else -> Color(0xFF0369A1)
                                    }
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = Color.DarkGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            statusOptions.forEach { st ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(st, fontWeight = if (st == status) FontWeight.Bold else FontWeight.Normal)
                                            if (st == status) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = PrimaryGreen)
                                            }
                                        }
                                    },
                                    onClick = {
                                        onStatusSelected(st)
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (status) {
                            "حاضر" -> Color(0xFFDCFCE7)
                            "غایب" -> Color(0xFFFEE2E2)
                            "غیرموجه" -> Color(0xFFFFEDD5)
                            else -> Color(0xFFE0F2FE)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "قفل ویرایش",
                                modifier = Modifier.size(12.dp),
                                tint = when (status) {
                                    "حاضر" -> Color(0xFF166534)
                                    "غایب" -> Color(0xFFB91C1C)
                                    "غیرموجه" -> Color(0xFFC2410C)
                                    else -> Color(0xFF0369A1)
                                }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = status,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = when (status) {
                                    "حاضر" -> Color(0xFF166534)
                                    "غایب" -> Color(0xFFB91C1C)
                                    "غیرموجه" -> Color(0xFFC2410C)
                                    else -> Color(0xFF0369A1)
                                }
                            )
                        }
                    }
                }

                // دکمه ویرایش مشخصات دانش‌آموز
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "ویرایش مشخصات",
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // دکمه حذف
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف دانش‌آموز",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * فرم جامع ثبت و ویرایش دانش‌آموز با تمام فیلدهای درخواستی کاربر
 */
@Composable
fun StudentFormDialog(
    initialStudent: Student?,
    existingStudents: List<Student>,
    onDismiss: () -> Unit,
    onRequestSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(initialStudent?.name ?: "") }
    var shad by remember { mutableStateOf(initialStudent?.shad ?: "") }
    var birthDate by remember { mutableStateOf(initialStudent?.birthDate ?: "") }
    var birthPlace by remember { mutableStateOf(initialStudent?.birthPlace ?: "") }

    var fatherName by remember { mutableStateOf(initialStudent?.fatherName ?: "") }
    var fatherBirthDate by remember { mutableStateOf(initialStudent?.fatherBirthDate ?: "") }
    var fatherJob by remember { mutableStateOf(initialStudent?.fatherJob ?: "") }
    var fatherEducation by remember { mutableStateOf(initialStudent?.fatherEducation ?: "") }

    var motherName by remember { mutableStateOf(initialStudent?.motherName ?: "") }
    var motherBirthDate by remember { mutableStateOf(initialStudent?.motherBirthDate ?: "") }
    var motherJob by remember { mutableStateOf(initialStudent?.motherJob ?: "") }
    var motherEducation by remember { mutableStateOf(initialStudent?.motherEducation ?: "") }

    var photoUri by remember { mutableStateOf(initialStudent?.photoUri ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // راه‌اندازی انتخابگر عکس با Photo Picker ایمن بدون نیاز به مجوز
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialStudent != null) "ویرایش اطلاعات دانش‌آموز" else "ثبت اطلاعات دانش‌آموز جدید",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // نمایش پیام خطای اعتبارسنجی
                errorMessage?.let { msg ->
                    Surface(
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(msg, color = Color(0xFFB91C1C), fontSize = 12.sp)
                        }
                    }
                }

                // بخش ۱: تصویر دانش‌آموز
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (photoUri.isNotBlank()) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "عکس دانش‌آموز",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Button(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (photoUri.isNotBlank()) "تغییر عکس" else "انتخاب عکس", fontSize = 12.sp)
                            }

                            if (photoUri.isNotBlank()) {
                                TextButton(
                                    onClick = { photoUri = "" },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626)),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text("حذف عکس", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // بخش ۲: مشخصات فردی دانش‌آموز
                Text("مشخصات فردی دانش‌آموز:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryGreenDark)

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("نام و نام خانوادگی * (اجباری)") },
                    singleLine = true,
                    isError = name.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = shad,
                    onValueChange = {
                        shad = it
                        errorMessage = null
                    },
                    label = { Text("شماره شاد * (اجباری)") },
                    singleLine = true,
                    isError = shad.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = birthDate,
                        onValueChange = { birthDate = it },
                        label = { Text("تاریخ تولد") },
                        placeholder = { Text("۱۳۹۴/۰۷/۱۰") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = birthPlace,
                        onValueChange = { birthPlace = it },
                        label = { Text("محل تولد") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // بخش ۳: مشخصات پدر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات پدر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0369A1))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("نام پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatherBirthDate,
                        onValueChange = { fatherBirthDate = it },
                        label = { Text("تاریخ تولد پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fatherJob,
                        onValueChange = { fatherJob = it },
                        label = { Text("شغل پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatherEducation,
                        onValueChange = { fatherEducation = it },
                        label = { Text("تحصیلات پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // بخش ۴: مشخصات مادر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات مادر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF9333EA))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("نام مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = motherBirthDate,
                        onValueChange = { motherBirthDate = it },
                        label = { Text("تاریخ تولد مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = motherJob,
                        onValueChange = { motherJob = it },
                        label = { Text("شغل مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = motherEducation,
                        onValueChange = { motherEducation = it },
                        label = { Text("تحصیلات مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedName = name.trim()
                    val trimmedShad = shad.trim()

                    // ۱. اعتبارسنجی فیلدهای اجباری
                    if (trimmedName.isBlank()) {
                        errorMessage = "نام و نام خانوادگی اجباری است."
                        return@Button
                    }
                    if (trimmedShad.isBlank()) {
                        errorMessage = "شماره شاد اجباری است."
                        return@Button
                    }

                    // ۲. بررسی عدم ثبت تکراری دانش‌آموز (نام یا شماره شاد)
                    val isDuplicate = existingStudents.any { other ->
                        val isSameStudent = initialStudent != null && other.id == initialStudent.id
                        !isSameStudent && (
                            other.name.trim().equals(trimmedName, ignoreCase = true) ||
                            (other.shad.isNotBlank() && other.shad.trim() == trimmedShad)
                        )
                    }

                    if (isDuplicate) {
                        errorMessage = "دانش‌آموزی با این نام یا شماره شاد قبلاً در کلاس ثبت شده است و امکان ثبت تکراری وجود ندارد!"
                        return@Button
                    }

                    val updatedOrNew = Student(
                        id = initialStudent?.id ?: System.currentTimeMillis(),
                        name = trimmedName,
                        status = initialStudent?.status ?: "حاضر",
                        shad = trimmedShad,
                        birthDate = birthDate.trim(),
                        birthPlace = birthPlace.trim(),
                        fatherName = fatherName.trim(),
                        fatherBirthDate = fatherBirthDate.trim(),
                        fatherJob = fatherJob.trim(),
                        fatherEducation = fatherEducation.trim(),
                        motherName = motherName.trim(),
                        motherBirthDate = motherBirthDate.trim(),
                        motherJob = motherJob.trim(),
                        motherEducation = motherEducation.trim(),
                        photoUri = photoUri,
                        birthMonth = initialStudent?.birthMonth ?: "مهر",
                        evaluations = initialStudent?.evaluations ?: emptyList()
                    )

                    onRequestSave(updatedOrNew)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text(if (initialStudent != null) "ثبت تغییرات" else "ثبت دانش‌آموز", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

/**
 * دیالوگ شناسنامه کامل دانش‌آموز با نمایش عکس، مشخصات شناسنامه‌ای و اطلاعات والدین
 */
@Composable
fun StudentProfileDetailDialog(
    student: Student,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("شناسنامه دانش‌آموز", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "بستن")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // کارت سربرگ مشخصات دانش‌آموز با عکس
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (student.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = student.photoUri,
                                contentDescription = "عکس ${student.name}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.name.take(1),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryGreenDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "شماره شاد: ${student.shad.ifBlank { "ثبت نشده" }}",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "وضعیت جاری: ${student.status}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (student.status) {
                                    "حاضر" -> PrimaryGreenDark
                                    "غایب" -> Color(0xFFDC2626)
                                    "غیرموجه" -> Color(0xFFEA580C)
                                    else -> Color(0xFF0284C7)
                                }
                            )
                        }
                    }
                }

                // مشخصات فردی
                InfoSectionCard(title = "اطلاعات شناسنامه‌ای دانش‌آموز", icon = Icons.Default.Badge, tint = PrimaryGreenDark) {
                    InfoRow(label = "تاریخ تولد:", value = student.birthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "محل تولد:", value = student.birthPlace.ifBlank { "ثبت نشده" })
                }

                // مشخصات پدر
                InfoSectionCard(title = "مشخصات پدر", icon = Icons.Default.Person, tint = Color(0xFF0369A1)) {
                    InfoRow(label = "نام پدر:", value = student.fatherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد پدر:", value = student.fatherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل پدر:", value = student.fatherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات پدر:", value = student.fatherEducation.ifBlank { "ثبت نشده" })
                }

                // مشخصات مادر
                InfoSectionCard(title = "مشخصات مادر", icon = Icons.Default.PersonOutline, tint = Color(0xFF9333EA)) {
                    InfoRow(label = "نام مادر:", value = student.motherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد مادر:", value = student.motherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل مادر:", value = student.motherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات مادر:", value = student.motherEducation.ifBlank { "ثبت نشده" })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onEdit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("ویرایش مشخصات")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDelete,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626))
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف دانش‌آموز")
            }
        }
    )
}

@Composable
fun InfoSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(0.5.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = tint)
            }
            Spacer(modifier = Modifier.height(6.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}

@Composable
fun StatPill(
    title: String,
    count: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            fontSize = 11.sp,
            color = TextSecondary
        )
        Text(
            text = count,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
