package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppState
import com.example.ui.theme.*
import java.util.Calendar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: AppState,
    onNavigate: (Screen) -> Unit,
    onDateChange: (String) -> Unit,
    onDayTypeChange: (String) -> Unit,
    onExportBackup: () -> String,
    onImportBackup: (String) -> Boolean,
    onSyncWithDeviceDate: () -> String = { "" }
) {
    val context = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showDateDialog by remember { mutableStateOf(false) }
    var exportJsonText by remember { mutableStateOf("") }
    var importInputText by remember { mutableStateOf("") }
    var tempDateText by remember { mutableStateOf(state.currentDateShamsi) }

    var isRefreshing by remember { mutableStateOf(false) }
    val refreshRotationAngle by animateFloatAsState(
        targetValue = if (isRefreshing) 360f else 0f,
        animationSpec = tween(durationMillis = 500),
        finishedListener = { isRefreshing = false },
        label = "refreshRotation"
    )

    val absentCount = state.students.count { it.status == "غایب" || it.status == "غیرموجه" }

    var showBirthdaysDialog by remember { mutableStateOf(false) }

    val allPersianMonths = remember {
        listOf(
            "فروردین", "اردیبهشت", "خرداد",
            "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر",
            "دی", "بهمن", "اسفند"
        )
    }

    val currentMonthName = remember(state.currentDateShamsi) {
        var month = com.example.util.DateUtils.getCurrentJalaliDate().monthName
        if (state.currentDateShamsi.isNotBlank()) {
            val eng = com.example.util.DateUtils.toEnglishDigits(state.currentDateShamsi)
            val parts = eng.split("/")
            if (parts.size >= 2) {
                val m = parts[1].toIntOrNull()
                if (m != null && m in 1..12) {
                    month = allPersianMonths[m - 1]
                }
            }
        }
        month
    }

    fun isStudentBornInTargetMonth(student: com.example.model.Student, targetMonth: String): Boolean {
        if (student.birthMonth.trim().equals(targetMonth.trim(), ignoreCase = true)) {
            return true
        }
        if (student.birthDate.isNotBlank()) {
            val eng = com.example.util.DateUtils.toEnglishDigits(student.birthDate)
            val parts = eng.split("/")
            if (parts.size >= 2) {
                val m = parts[1].toIntOrNull()
                if (m != null && m in 1..12) {
                    if (allPersianMonths[m - 1] == targetMonth) {
                        return true
                    }
                }
            }
            if (student.birthDate.contains(targetMonth)) {
                return true
            }
        }
        return false
    }

    val birthdayStudentsThisMonth = remember(state.students, currentMonthName) {
        state.students.filter { isStudentBornInTargetMonth(it, currentMonthName) }
    }

    val realTodayName = remember {
        com.example.util.DateUtils.getCurrentDayOfWeek()
    }
    val defaultSchoolDay = remember {
        if (realTodayName in listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")) realTodayName else "شنبه"
    }
    var selectedDayForSchedule by remember { mutableStateOf(defaultSchoolDay) }

    val performSyncDateAndSchedule: () -> Unit = {
        isRefreshing = true
        val freshJalali = com.example.util.DateUtils.getCurrentJalaliDate()
        val freshDate = freshJalali.toFormattedString()
        val freshDay = com.example.util.DateUtils.getCurrentDayOfWeek()

        val targetDay = if (freshDay in listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")) {
            freshDay
        } else {
            if (state.weeklySchedule.any { it.dayName == freshDay }) freshDay else "شنبه"
        }

        val wasDifferent = (state.currentDateShamsi != freshDate)
        onSyncWithDeviceDate()
        if (wasDifferent) {
            onDateChange(freshDate)
        }
        selectedDayForSchedule = targetDay

        val msg = if (wasDifferent) {
            "تاریخ به ${com.example.util.DateUtils.toPersianDigits(freshDate)} بروزرسانی شد و برنامه $targetDay نمایش داده شد."
        } else {
            "تاریخ و برنامه روزانه با زمان گوشی همگام است ($targetDay ${com.example.util.DateUtils.toPersianDigits(freshDate)})"
        }
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun getPeriodOrdinal(index: Int): String {
        return when (index) {
            0 -> "زنگ اول"
            1 -> "زنگ دوم"
            2 -> "زنگ سوم"
            3 -> "زنگ چهارم"
            4 -> "زنگ پنجم"
            5 -> "زنگ ششم"
            6 -> "زنگ هفتم"
            7 -> "زنگ هشتم"
            else -> "زنگ ${index + 1}"
        }
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxHeight(),
                drawerContainerColor = Color.White
            ) {
                // سربرگ اطلاعات پروفایل معلم و مشخصات کلاس در منوی همبرگری
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PrimaryGreen)
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = state.profile.teacherName.ifBlank { "معلم گرامی" },
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = state.profile.schoolName.ifBlank { "دبستان هوشمند" },
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.18f)
                        ) {
                            Text(
                                text = state.profile.educationalTitle.ifBlank { "آموزگار محترم" },
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "منوی اصلی و ابزارها",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )

                // ۱. تنظیمات پروفایل
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.ManageAccounts,
                            contentDescription = null,
                            tint = TeacherTeal
                        )
                    },
                    label = {
                        Column {
                            Text("تنظیمات پروفایل", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("نام معلم، مدرسه و سال تحصیلی", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.PROFILE_SETTINGS)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_profile")
                )

                // ۲. مدیریت دروس
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = SkyBlue
                        )
                    },
                    label = {
                        Column {
                            Text("مدیریت دروس", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("فعال‌سازی و ویرایش عناوین دروس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SkyBlue.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${state.subjects.size} درس",
                                fontSize = 11.sp,
                                color = SkyBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.SUBJECTS)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_subjects")
                )

                // ۳. ویرایش برنامه هفتگی
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryGreen
                        )
                    },
                    label = {
                        Column {
                            Text("ویرایش برنامه هفتگی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("تنظیم زنگ‌های درسی شنبه تا چهارشنبه", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PrimaryGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "۵ روز",
                                fontSize = 11.sp,
                                color = PrimaryGreenDark,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.SCHEDULE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_schedule")
                )

                // ۴. ارزیابی عملکرد و تایم‌لاین دانش‌آموزان
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QueryStats,
                            contentDescription = null,
                            tint = SkyBlue
                        )
                    },
                    label = {
                        Column {
                            Text("ارزیابی عملکرد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("تایم‌لاین، آمار غیبت‌ها و وضعیت دروس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    badge = {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SkyBlue.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${state.students.size} دانش‌آموز",
                                fontSize = 11.sp,
                                color = SkyBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.PERFORMANCE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_performance")
                )

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = BorderLight, modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(modifier = Modifier.height(8.dp))

                // ۴. پشتیبان‌گیری و بازگردانی
                NavigationDrawerItem(
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SettingsBackupRestore,
                            contentDescription = null,
                            tint = Color(0xFF0284C7)
                        )
                    },
                    label = {
                        Column {
                            Text("پشتیبان‌گیری و بازگردانی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("ذخیره در حافظه دستگاه و بازیابی اطلاعات کلاس", fontSize = 11.sp, color = TextSecondary)
                        }
                    },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        onNavigate(Screen.BACKUP_RESTORE)
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .testTag("drawer_item_backup")
                )

                Spacer(modifier = Modifier.weight(1f))
                HorizontalDivider(color = BorderLight, modifier = Modifier.padding(horizontal = 16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "طراح حامد صبوری ورژن برنامه ۲۰۰۶۰۵",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "دفتر مدیریت کلاسی",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            modifier = Modifier.testTag("hamburger_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "منوی همبرگری",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PrimaryGreen,
                        actionIconContentColor = Color.White
                    ),
                    actions = {
                        // دکمه کوچک بروزرسانی و همگام‌سازی تاریخ و برنامه روزانه با گوشی
                        IconButton(
                            onClick = performSyncDateAndSchedule,
                            modifier = Modifier.testTag("top_bar_sync_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = "بروزرسانی تاریخ و برنامه روزانه",
                                tint = Color.White,
                                modifier = Modifier.graphicsLayer(rotationZ = refreshRotationAngle)
                            )
                        }
                        IconButton(
                            onClick = { onNavigate(Screen.BACKUP_RESTORE) },
                            modifier = Modifier.testTag("backup_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SettingsBackupRestore,
                                contentDescription = "پشتیبان‌گیری و بازگردانی",
                                tint = Color.White
                            )
                        }
                    }
                )
            }
        ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
                .verticalScroll(rememberScrollState())
        ) {
            // ۱. نوار وضعیت روز و تاریخ
            Surface(
                color = PrimaryGreen.copy(alpha = 0.12f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    tempDateText = state.currentDateShamsi
                                    showDateDialog = true
                                }
                                .padding(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = "تغییر تاریخ",
                                tint = PrimaryGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تاریخ: ${com.example.util.DateUtils.toPersianDigits(state.currentDateShamsi)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = PrimaryGreenDark
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // دکمه کوچک بروزرسانی سریع تاریخ
                        Surface(
                            onClick = performSyncDateAndSchedule,
                            shape = RoundedCornerShape(8.dp),
                            color = PrimaryGreen.copy(alpha = 0.18f),
                            modifier = Modifier.testTag("date_bar_sync_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "بروزرسانی با ساعت گوشی",
                                    tint = PrimaryGreenDark,
                                    modifier = Modifier
                                        .size(15.dp)
                                        .graphicsLayer(rotationZ = refreshRotationAngle)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "بروزرسانی",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryGreenDark
                                )
                            }
                        }
                    }

                    // انتخاب حالت روز
                    var dayTypeExpanded by remember { mutableStateOf(false) }
                    Box {
                        Surface(
                            onClick = { dayTypeExpanded = true },
                            color = Color.White,
                            shape = RoundedCornerShape(8.dp),
                            shadowElevation = 1.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = state.dayType,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = PrimaryGreen
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = PrimaryGreen
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = dayTypeExpanded,
                            onDismissRequest = { dayTypeExpanded = false }
                        ) {
                            listOf("روز عادی", "روز تعطیل", "آموزش مجازی").forEach { type ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = type,
                                            fontWeight = if (state.dayType == type) FontWeight.Bold else FontWeight.Normal,
                                            color = if (state.dayType == type) PrimaryGreen else Color.Unspecified
                                        )
                                    },
                                    onClick = {
                                        onDayTypeChange(type)
                                        dayTypeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ۲. خلاصه وضعیت روزانه (غایبین)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onNavigate(Screen.ATTENDANCE) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonOff,
                        contentDescription = null,
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "غایبین امروز: $absentCount نفر",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "(مشاهده و ویرایش)",
                        fontSize = 12.sp,
                        color = Color(0xFFD32F2F).copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ۲.۲ متولدین این ماه
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { showBirthdaysDialog = true }
                    .testTag("home_birthdays_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                border = BorderStroke(1.dp, Color(0xFFFED7AA)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Cake,
                        contentDescription = "متولدین این ماه",
                        tint = Color(0xFFEA580C),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "متولدین این ماه ($currentMonthName): ${com.example.util.DateUtils.toPersianDigits(birthdayStudentsThisMonth.size)} نفر",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFEA580C)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "(مشاهده اسامی 🎂)",
                        fontSize = 12.sp,
                        color = Color(0xFFEA580C).copy(alpha = 0.85f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ۲.۵ نوار برنامه هفتگی دروس همان روز
            val todaySchedule = state.weeklySchedule.find { it.dayName == selectedDayForSchedule }
            val todayPeriods = todaySchedule?.periods ?: emptyList()
            val schoolDays = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("home_schedule_preview_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = PrimaryGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "برنامه درسی امروز ($selectedDayForSchedule):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // دکمه همگام‌سازی برنامه با امروز
                            Surface(
                                onClick = performSyncDateAndSchedule,
                                shape = RoundedCornerShape(8.dp),
                                color = PrimaryGreen.copy(alpha = 0.12f),
                                modifier = Modifier.testTag("schedule_sync_today_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = "همگام با امروز",
                                        tint = PrimaryGreenDark,
                                        modifier = Modifier
                                            .size(13.dp)
                                            .graphicsLayer(rotationZ = refreshRotationAngle)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "امروز",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryGreenDark
                                    )
                                }
                            }

                            // دکمه ویرایش سریع برنامه هفتگی
                            Surface(
                                onClick = { onNavigate(Screen.SUBJECTS) },
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFF1F5F9)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "ویرایش برنامه",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ویرایش",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextSecondary
                                    )
                                }
                            }

                            // انتخاب روز دیگر برای مشاهده سریع برنامه سایر روزها
                            var dayMenuExpanded by remember { mutableStateOf(false) }
                            Box {
                                Surface(
                                    onClick = { dayMenuExpanded = true },
                                    shape = RoundedCornerShape(8.dp),
                                    color = PrimaryGreen.copy(alpha = 0.08f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "تغییر روز",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = PrimaryGreenDark
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = PrimaryGreenDark,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = dayMenuExpanded,
                                    onDismissRequest = { dayMenuExpanded = false }
                                ) {
                                    schoolDays.forEach { d ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = if (d == realTodayName) "$d (امروز)" else d,
                                                    fontWeight = if (d == selectedDayForSchedule) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (d == selectedDayForSchedule) PrimaryGreen else TextPrimary
                                                )
                                            },
                                            onClick = {
                                                selectedDayForSchedule = d
                                                dayMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // نمایش ۵ زنگ و درس هر زنگ در یک نگاه با اندازه و ابعاد کاملاً یکسان و یکنواخت
                    val periodsToDisplay = (0 until 5).map { index ->
                        todayPeriods.getOrNull(index)?.ifBlank { "—" } ?: "—"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_schedule_five_periods_row"),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        periodsToDisplay.forEachIndexed { index, subjectName ->
                            val ordinal = getPeriodOrdinal(index)
                            val isAssigned = subjectName != "—" && subjectName.isNotBlank()
                            val periodColor = when (index) {
                                0 -> PrimaryGreen
                                1 -> SkyBlue
                                2 -> Color(0xFFD97706)
                                3 -> TeacherTeal
                                else -> MeetingPurple
                            }
                            val periodBg = when (index) {
                                0 -> PrimaryGreen.copy(alpha = 0.08f)
                                1 -> SkyBlue.copy(alpha = 0.08f)
                                2 -> AmberSecondary.copy(alpha = 0.12f)
                                3 -> TeacherTeal.copy(alpha = 0.08f)
                                else -> MeetingPurple.copy(alpha = 0.08f)
                            }

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(106.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onNavigate(Screen.SUBJECTS) }
                                    .testTag("home_schedule_period_${index + 1}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isAssigned) periodBg else Color(0xFFF8FAFC),
                                border = BorderStroke(
                                    1.dp,
                                    if (isAssigned) periodColor.copy(alpha = 0.35f) else BorderLight
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 2.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // نشانگر شماره زنگ (اندازه ثابت و یکسان در تمام ۵ زنگ)
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isAssigned) periodColor else Color(0xFF94A3B8),
                                        modifier = Modifier.height(20.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(horizontal = 4.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "زنگ ${com.example.util.DateUtils.toPersianDigits(index + 1)}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }

                                    // نام درس هر زنگ (فضای مساوی با تراز عمودی و افقی در مرکز)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxWidth()
                                            .padding(horizontal = 1.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isAssigned) subjectName else "بدون درس",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = if (subjectName.length > 8) 10.sp else 11.5.sp,
                                            color = if (isAssigned) TextPrimary else TextSecondary.copy(alpha = 0.65f),
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            lineHeight = 14.5.sp,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    // برچسب ترتیب زنگ (ارتفاع و جایگاه کاملاً هماهنگ)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isAssigned) periodColor.copy(alpha = 0.12f) else Color(0xFFF1F5F9),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(18.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.fillMaxSize(),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = when (index) {
                                                    0 -> "اول"
                                                    1 -> "دوم"
                                                    2 -> "سوم"
                                                    3 -> "چهارم"
                                                    4 -> "پنجم"
                                                    else -> "${index + 1}"
                                                },
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isAssigned) periodColor else TextSecondary.copy(alpha = 0.7f),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ۳. شبکه منوهای اصلی سیستم (دسترسی سریع)
            Text(
                text = "دسترسی سریع",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                // سطر اول: حضور و غیاب / ارزشیابی و تکالیف
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "حضور و غیاب",
                            icon = Icons.Default.HowToReg,
                            color = PrimaryGreen,
                            badge = "${state.students.size} دانش‌آموز",
                            onClick = { onNavigate(Screen.ATTENDANCE) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "ارزشیابی و تکالیف",
                            icon = Icons.Default.AssignmentTurnedIn,
                            color = EvaluationOrange,
                            badge = "${state.subjects.count { it.enabled }} درس فعال",
                            onClick = { onNavigate(Screen.EVALUATION) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // سطر دوم: امتیازات گروهی / یادداشت‌های معلم
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "امتیازات گروهی",
                            icon = Icons.Default.Star,
                            color = AmberSecondary,
                            badge = "${state.groups.size} گروه",
                            onClick = { onNavigate(Screen.GROUPS) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "یادداشت‌های معلم",
                            icon = Icons.Default.NoteAlt,
                            color = TeacherTeal,
                            badge = "${state.teacherNotes.size} یادداشت",
                            onClick = { onNavigate(Screen.NOTES) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // سطر سوم: ارزیابی عملکرد / جلسات اولیا
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "ارزیابی عملکرد",
                            icon = Icons.Default.QueryStats,
                            color = SkyBlue,
                            badge = "تایم‌لاین و وضعیت",
                            onClick = { onNavigate(Screen.PERFORMANCE) }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        DashboardCard(
                            title = "جلسات اولیا و مربیان",
                            icon = Icons.Default.Groups,
                            color = MeetingPurple,
                            badge = "${state.parentMeetings.size} جلسه ثبت‌شده",
                            onClick = { onNavigate(Screen.MEETINGS) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

    // دیالوگ تغییر تاریخ شمسی
    if (showDateDialog) {
        AlertDialog(
            onDismissRequest = { showDateDialog = false },
            title = { Text("تنظیم تاریخ شمسی") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = tempDateText,
                        onValueChange = { tempDateText = it },
                        label = { Text("تاریخ شمسی") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            tempDateText = com.example.util.DateUtils.getCurrentShamsiDate()
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تنظیم تاریخ امروز گوشی (${com.example.util.DateUtils.getCurrentShamsiDate()})", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (tempDateText.isNotBlank()) {
                            onDateChange(tempDateText.trim())
                        }
                        showDateDialog = false
                    }
                ) {
                    Text("تایید")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDateDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ پشتیبان‌گیری (خروجی گرفتن)
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("کد پشتیبان‌گیری شما", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "این متن را کپی کرده و در گوشی جدید جهت بازگردانی وارد کنید:",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFFECEFF1),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(8.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = exportJsonText,
                                fontSize = 11.sp,
                                color = Color(0xFF37474F)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("ClassManager Backup", exportJsonText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "کد پشتیبان‌گیری در حافظه کپی شد", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("کپی کد")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("بستن")
                }
            }
        )
    }

    // دیالوگ بازگردانی اطلاعات (Import)
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("بازگردانی اطلاعات", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "کد پشتیبان‌گیری صادر شده را در کادر زیر جای‌گذاری کنید:",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("کد پشتیبان‌گیری را اینجا پیست کنید...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        maxLines = 6
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importInputText.isNotBlank()) {
                            val success = onImportBackup(importInputText.trim())
                            if (success) {
                                Toast.makeText(context, "اطلاعات با موفقیت بازگردانی شد.", Toast.LENGTH_LONG).show()
                                showImportDialog = false
                            } else {
                                Toast.makeText(context, "کد وارد شده معتبر نیست!", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("بازگردانی")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ نمایش لیست متولدین این ماه
    if (showBirthdaysDialog) {
        var selectedMonthForView by remember(currentMonthName) { mutableStateOf(currentMonthName) }
        val studentsInSelectedMonth = remember(state.students, selectedMonthForView) {
            state.students.filter { isStudentBornInTargetMonth(it, selectedMonthForView) }
        }
        var monthDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBirthdaysDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFED7AA)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cake,
                                contentDescription = null,
                                tint = Color(0xFFEA580C),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "متولدین ماه $selectedMonthForView",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF9A3412)
                            )
                            Text(
                                text = "${com.example.util.DateUtils.toPersianDigits(studentsInSelectedMonth.size)} دانش‌آموز",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // امکان مشاهده متولدین سایر ماه‌ها
                    Box {
                        Surface(
                            onClick = { monthDropdownExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFF7ED),
                            border = BorderStroke(1.dp, Color(0xFFFED7AA))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "تغییر ماه",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFEA580C)
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = Color(0xFFEA580C),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = monthDropdownExpanded,
                            onDismissRequest = { monthDropdownExpanded = false }
                        ) {
                            allPersianMonths.forEach { m ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (m == currentMonthName) "$m (این ماه)" else m,
                                            fontWeight = if (m == selectedMonthForView) FontWeight.Bold else FontWeight.Normal,
                                            color = if (m == selectedMonthForView) Color(0xFFEA580C) else TextPrimary
                                        )
                                    },
                                    onClick = {
                                        selectedMonthForView = m
                                        monthDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (studentsInSelectedMonth.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "🎂", fontSize = 38.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "در ماه $selectedMonthForView دانش‌آموزی متولد نشده است.",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "جهت تغییر ماه از دکمه بالای کادر استفاده کنید.",
                                    fontSize = 11.sp,
                                    color = TextSecondary.copy(alpha = 0.8f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 320.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(studentsInSelectedMonth, key = { it.id }) { student ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFFFF7ED),
                                    border = BorderStroke(1.dp, Color(0xFFFED7AA)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFFEDD5)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = "🎈", fontSize = 20.sp)
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = TextPrimary
                                            )
                                            if (student.birthDate.isNotBlank()) {
                                                Text(
                                                    text = "تاریخ تولد: ${com.example.util.DateUtils.toPersianDigits(student.birthDate)}",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            } else {
                                                Text(
                                                    text = "متولد: $selectedMonthForView",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                        }

                                        // دکمه کپی پیام تبریک اختصاصی برای این دانش‌آموز
                                        IconButton(
                                            onClick = {
                                                val msg = "🎉 گل پسر/دختر گلم، ${student.name} عزیز، زادروزت در ماه $selectedMonthForView فرخنده و شاد باد! با آرزوی روزهایی پر از موفقیت و سربلندی. معلم مهربان شما 🎂🎈"
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val clip = ClipData.newPlainText("تبریک تولد", msg)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "پیام تبریک برای ${student.name} کپی شد.", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "کپی پیام تبریک",
                                                tint = Color(0xFFEA580C),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // دکمه کپی پیام تبریک عمومی ماهانه
                        Button(
                            onClick = {
                                val studentNames = studentsInSelectedMonth.joinToString("، ") { it.name }
                                val groupMessage = "🌸 با افتخار و شادمانی، زادروز شکوفه‌های کلاسمان در ماه $selectedMonthForView ($studentNames) را صمیمانه شادباش می‌گوییم. از درگاه خداوند برای این عزیزان سلامتی، شادی و توفیق روزافزون آرزومندیم. 🎂🎈🎉"
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("تبریک کلاسی", groupMessage)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "متن تبریک گروهی کپی شد.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "کپی متن تبریک کلاسی برای شاد",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBirthdaysDialog = false }) {
                    Text("بستن", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun DashboardCard(
    title: String,
    icon: ImageVector,
    color: Color,
    badge: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(148.dp)
            .clickable { onClick() }
            .testTag("dashboard_card_${title}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(color.copy(alpha = 0.15f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = badge,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}
