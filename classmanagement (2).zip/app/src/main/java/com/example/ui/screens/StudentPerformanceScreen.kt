package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.DailyAttendance
import com.example.model.Evaluation
import com.example.model.GroupItem
import com.example.model.Student
import com.example.model.SubjectItem
import com.example.ui.theme.*
import com.example.util.DateUtils

// --- مدل‌های داده تحلیلی ارزیابی عملکرد ---

data class SubjectBreakdown(
    val subjectName: String,
    val totalCount: Int,
    val veryGoodCount: Int,
    val goodCount: Int,
    val acceptableCount: Int,
    val needsWorkCount: Int,
    val latestScore: String?,
    val latestDate: String?,
    val overallStatus: String
)

sealed class PerformanceTimelineItem(
    open val date: String,
    open val sortKey: String
) {
    data class AttendanceRecordItem(
        override val date: String,
        val status: String,
        override val sortKey: String
    ) : PerformanceTimelineItem(date, sortKey)

    data class EvaluationRecordItem(
        override val date: String,
        val evaluation: Evaluation,
        override val sortKey: String
    ) : PerformanceTimelineItem(date, sortKey)
}

data class StudentPerformanceSummary(
    val student: Student,
    val totalAbsences: Int,
    val unexcusedAbsences: Int,
    val excusedAbsences: Int,
    val presentCount: Int,
    val attendanceRate: Int,
    val absenceList: List<Pair<String, String>>, // تاریخ و نوع غیبت
    val totalEvaluations: Int,
    val veryGoodCount: Int,
    val goodCount: Int,
    val acceptableCount: Int,
    val needsWorkCount: Int,
    val overallTier: String,
    val overallScoreOutOf4: Float,
    val groupName: String?,
    val subjectBreakdowns: List<SubjectBreakdown>,
    val timelineEvents: List<PerformanceTimelineItem>
)

/**
 * صفحه ارزیابی عملکرد و تایم‌لاین دانش‌آموزان
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentPerformanceScreen(
    students: List<Student>,
    subjects: List<SubjectItem>,
    attendanceHistory: List<DailyAttendance>,
    groups: List<GroupItem>,
    currentDate: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    // شناسه دانش‌آموز انتخاب‌شده برای مشاهده تایم‌لاین تفصیلی
    var selectedStudentId by remember { mutableStateOf<Long?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var listFilterTab by remember { mutableIntStateOf(0) } // ۰: همه، ۱: دارای غیبت، ۲: عملکرد عالی، ۳: نیازمند پیگیری

    // استخراج و محاسبه خلاصه عملکرد تمامی دانش‌آموزان
    val allSummaries = remember(students, subjects, attendanceHistory, groups, currentDate) {
        students.map { student ->
            calculateStudentSummary(
                student = student,
                subjects = subjects,
                attendanceHistory = attendanceHistory,
                groups = groups,
                currentDate = currentDate
            )
        }
    }

    // دانش‌آموز انتخابی فعلی
    val currentSelectedSummary = remember(selectedStudentId, allSummaries) {
        allSummaries.find { it.student.id == selectedStudentId }
    }

    // فیلتر کردن لیست دانش‌آموزان بر اساس جستجو و دسته‌بندی
    val filteredSummaries = remember(allSummaries, searchQuery, listFilterTab) {
        allSummaries.filter { summary ->
            val matchesQuery = searchQuery.isBlank() ||
                    summary.student.name.contains(searchQuery.trim(), ignoreCase = true) ||
                    (summary.groupName?.contains(searchQuery.trim(), ignoreCase = true) == true)

            val matchesFilter = when (listFilterTab) {
                1 -> summary.totalAbsences > 0
                2 -> summary.overallTier.startsWith("خیلی خوب")
                3 -> summary.totalAbsences >= 2 || summary.needsWorkCount > 0
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (currentSelectedSummary != null)
                                "کارنامه و تایم‌لاین ${currentSelectedSummary.student.name}"
                            else
                                "ارزیابی عملکرد دانش‌آموزان",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (currentSelectedSummary != null)
                                "تایم‌لاین وضعیت، آمار غیبت‌ها و عملکرد دروس"
                            else
                                "${DateUtils.toPersianDigits(students.size)} دانش‌آموز • وضعیت کلی و تایم‌لاین",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedStudentId != null) {
                            selectedStudentId = null
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SkyBlue)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            AnimatedContent(
                targetState = currentSelectedSummary,
                label = "PerformanceScreenTransition"
            ) { summary ->
                if (summary == null) {
                    // نمای ۱: لیست همه دانش‌آموزان به همراه کارت‌های ارزیابی سریع
                    StudentsOverviewList(
                        summaries = filteredSummaries,
                        totalStudentsCount = students.size,
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        filterTab = listFilterTab,
                        onFilterTabChange = { listFilterTab = it },
                        onSelectStudent = { selectedStudentId = it.student.id }
                    )
                } else {
                    // نمای ۲: تایم‌لاین وضعیت دقیق و تفکیک دروس و غیبت‌های دانش‌آموز
                    val currentIndex = allSummaries.indexOfFirst { it.student.id == summary.student.id }
                    val prevStudent = if (currentIndex > 0) allSummaries[currentIndex - 1] else null
                    val nextStudent = if (currentIndex < allSummaries.size - 1) allSummaries[currentIndex + 1] else null

                    StudentDetailedTimelineView(
                        summary = summary,
                        prevStudent = prevStudent,
                        nextStudent = nextStudent,
                        onSelectStudent = { selectedStudentId = it.student.id },
                        onBackToList = { selectedStudentId = null },
                        onCopyReport = { reportText ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("کارنامه دانش‌آموز", reportText)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "گزارش عملکرد در کلیپ‌بورد کپی شد.", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

// --- کامپوننت نمای ۱: لیست و خلاصه‌وضعیت کلی دانش‌آموزان ---

@Composable
private fun StudentsOverviewList(
    summaries: List<StudentPerformanceSummary>,
    totalStudentsCount: Int,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    filterTab: Int,
    onFilterTabChange: (Int) -> Unit,
    onSelectStudent: (StudentPerformanceSummary) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ۱. کارت خلاصه وضعیت کل کلاس
        item {
            ClassPerformanceHeaderCard(
                summaries = summaries,
                totalStudentsCount = totalStudentsCount
            )
        }

        // ۲. نوار جستجو
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("performance_search_field"),
                placeholder = { Text("جستجوی نام دانش‌آموز یا نام گروه...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = SkyBlue)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "پاک کردن", tint = TextSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = SkyBlue,
                    unfocusedBorderColor = BorderLight
                )
            )
        }

        // ۳. چیپ‌های فیلتر سریع
        item {
            val filterOptions = listOf("همه دانش‌آموزان", "دارای غیبت", "عملکرد عالی ⭐", "نیازمند پیگیری ⚠️")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(filterOptions) { index, label ->
                    FilterChip(
                        selected = filterTab == index,
                        onClick = { onFilterTabChange(index) },
                        label = {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (filterTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SkyBlue,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White
                        )
                    )
                }
            }
        }

        // راهنمای لمس
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = SkyBlue.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, SkyBlue.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = SkyBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "با لمس نام هر دانش‌آموز، تایم‌لاین کامل وضعیت، تفکیک دروس و غیبت‌ها نمایش داده می‌شود.",
                        fontSize = 11.sp,
                        color = Color(0xFF0369A1),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        if (summaries.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "دانش‌آموزی مطابق با جستجو یا فیلتر یافت نشد.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            // لیست کارت‌های دانش‌آموزان
            items(summaries, key = { it.student.id }) { summary ->
                StudentOverviewCard(
                    summary = summary,
                    onClick = { onSelectStudent(summary) }
                )
            }
        }
    }
}

@Composable
private fun ClassPerformanceHeaderCard(
    summaries: List<StudentPerformanceSummary>,
    totalStudentsCount: Int
) {
    val totalAbsences = summaries.sumOf { it.totalAbsences }
    val totalEvaluations = summaries.sumOf { it.totalEvaluations }
    val veryGoodCount = summaries.count { it.overallTier.startsWith("خیلی خوب") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SkyBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QueryStats,
                            contentDescription = null,
                            tint = SkyBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "شاخص‌های کلیدی کلاس",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "گزارش تجمیعی حضور، غیاب و ارزشیابی",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ۴ باکس آماری
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricMiniBox(
                    modifier = Modifier.weight(1f),
                    title = "دانش‌آموزان",
                    value = DateUtils.toPersianDigits(totalStudentsCount),
                    icon = Icons.Default.Group,
                    color = PrimaryGreen
                )
                MetricMiniBox(
                    modifier = Modifier.weight(1f),
                    title = "کل غیبت‌ها",
                    value = DateUtils.toPersianDigits(totalAbsences),
                    icon = Icons.Default.PersonOff,
                    color = if (totalAbsences > 0) Color(0xFFDC2626) else PrimaryGreen
                )
                MetricMiniBox(
                    modifier = Modifier.weight(1f),
                    title = "کل ارزشیابی",
                    value = DateUtils.toPersianDigits(totalEvaluations),
                    icon = Icons.Default.AssignmentTurnedIn,
                    color = EvaluationOrange
                )
                MetricMiniBox(
                    modifier = Modifier.weight(1f),
                    title = "سطح عالی",
                    value = DateUtils.toPersianDigits(veryGoodCount),
                    icon = Icons.Default.Star,
                    color = AmberSecondary
                )
            }
        }
    }
}

@Composable
private fun MetricMiniBox(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = color
            )
            Text(
                text = title,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun StudentOverviewCard(
    summary: StudentPerformanceSummary,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("student_perf_card_${summary.student.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // تصویر یا آواتار دانش‌آموز
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(SkyBlue.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                if (summary.student.photoUri.isNotBlank()) {
                    AsyncImage(
                        model = summary.student.photoUri,
                        contentDescription = summary.student.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = summary.student.name.firstOrNull()?.toString() ?: "د",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = SkyBlue
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // مشخصات و وضعیت
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = summary.student.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )

                    // نشان سطح عملکرد کلی
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when {
                            summary.overallTier.startsWith("خیلی خوب") -> Color(0xFF10B981).copy(alpha = 0.12f)
                            summary.overallTier.startsWith("خوب") -> SkyBlue.copy(alpha = 0.12f)
                            summary.overallTier.startsWith("قابل قبول") -> AmberSecondary.copy(alpha = 0.15f)
                            else -> Color(0xFFEF4444).copy(alpha = 0.12f)
                        }
                    ) {
                        Text(
                            text = summary.overallTier,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                summary.overallTier.startsWith("خیلی خوب") -> Color(0xFF047857)
                                summary.overallTier.startsWith("خوب") -> Color(0xFF0369A1)
                                summary.overallTier.startsWith("قابل قبول") -> Color(0xFFB45309)
                                else -> Color(0xFFDC2626)
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // برچسب‌های آمار غیبت و درس‌ها
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // بج غیبت
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (summary.totalAbsences == 0) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFFEE2E2)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (summary.totalAbsences == 0) Icons.Default.CheckCircle else Icons.Default.PersonOff,
                                contentDescription = null,
                                tint = if (summary.totalAbsences == 0) PrimaryGreenDark else Color(0xFFDC2626),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (summary.totalAbsences == 0)
                                    "بدون غیبت (۱۰۰٪)"
                                else
                                    "${DateUtils.toPersianDigits(summary.totalAbsences)} غیبت",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (summary.totalAbsences == 0) PrimaryGreenDark else Color(0xFFDC2626)
                            )
                        }
                    }

                    // بج ارزشیابی
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EvaluationOrange.copy(alpha = 0.08f)
                    ) {
                        Text(
                            text = "${DateUtils.toPersianDigits(summary.totalEvaluations)} ارزشیابی",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFC2410C),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (summary.groupName != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AmberSecondary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = summary.groupName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF92400E),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // آیکون فلش جهت ورود به تایم‌لاین
            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = "مشاهده تایم‌لاین",
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// --- کامپوننت نمای ۲: تایم‌لاین تفصیلی و کارنامه کامل دانش‌آموز ---

@Composable
private fun StudentDetailedTimelineView(
    summary: StudentPerformanceSummary,
    prevStudent: StudentPerformanceSummary?,
    nextStudent: StudentPerformanceSummary?,
    onSelectStudent: (StudentPerformanceSummary) -> Unit,
    onBackToList: () -> Unit,
    onCopyReport: (String) -> Unit
) {
    // تب‌های داخل کارنامه دانش‌آموز:
    // ۰: تایم‌لاین وضعیت ⏱️، ۱: به تفکیک دروس 📚، ۲: آمار غیبت‌ها 📅، ۳: کارنامه و ارسال 📋
    var detailTab by remember { mutableIntStateOf(0) }
    // فیلتر تایم‌لاین: ۰: همه رویدادها، ۱: فقط غیبت‌ها، ۲: فقط نمرات
    var timelineFilter by remember { mutableIntStateOf(0) }

    val tabs = listOf("تایم‌لاین وضعیت ⏱️", "به تفکیک دروس 📚", "آمار غیبت‌ها 📅", "کارنامه تحلیلی 📋")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ۱. هدر کارت دانش‌آموز با دکمه‌های ناوبری سریع
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    // نوار ناوبری دانش‌آموز قبلی / بعدی
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { if (prevStudent != null) onSelectStudent(prevStudent) },
                            enabled = prevStudent != null
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = prevStudent?.student?.name ?: "قبلی",
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SkyBlue.copy(alpha = 0.1f),
                            modifier = Modifier.clickable { onBackToList() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.List, contentDescription = null, tint = SkyBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("لیست کلاس", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SkyBlue)
                            }
                        }

                        TextButton(
                            onClick = { if (nextStudent != null) onSelectStudent(nextStudent) },
                            enabled = nextStudent != null
                        ) {
                            Text(
                                text = nextStudent?.student?.name ?: "بعدی",
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.ChevronLeft, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }

                    HorizontalDivider(color = BorderLight, modifier = Modifier.padding(vertical = 8.dp))

                    // اطلاعات فردی دانش‌آموز
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(SkyBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (summary.student.photoUri.isNotBlank()) {
                                AsyncImage(
                                    model = summary.student.photoUri,
                                    contentDescription = summary.student.name,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = summary.student.name.firstOrNull()?.toString() ?: "د",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = SkyBlue
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = summary.student.name,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (summary.student.fatherName.isNotBlank()) {
                                    Text(
                                        text = "فرزند ${summary.student.fatherName}",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                if (summary.groupName != null) {
                                    Text(
                                        text = "• «${summary.groupName}»",
                                        fontSize = 12.sp,
                                        color = Color(0xFFB45309),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ۲. سه کارت وضعیت شاخص (وضعیت کلی، آمار غیبت‌ها، ارزشیابی‌ها)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // کارت وضعیت کلی
                Card(
                    modifier = Modifier.weight(1.1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            summary.overallTier.startsWith("خیلی خوب") -> Color(0xFFECFDF5)
                            summary.overallTier.startsWith("خوب") -> Color(0xFFF0F9FF)
                            summary.overallTier.startsWith("قابل قبول") -> Color(0xFFFFFBEB)
                            else -> Color(0xFFFEF2F2)
                        }
                    ),
                    border = BorderStroke(
                        1.dp,
                        when {
                            summary.overallTier.startsWith("خیلی خوب") -> Color(0xFF6EE7B7)
                            summary.overallTier.startsWith("خوب") -> Color(0xFF7DD3FC)
                            summary.overallTier.startsWith("قابل قبول") -> Color(0xFFFDE68A)
                            else -> Color(0xFFFCA5A5)
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "وضعیت کلی", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = summary.overallTier,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = when {
                                summary.overallTier.startsWith("خیلی خوب") -> Color(0xFF047857)
                                summary.overallTier.startsWith("خوب") -> Color(0xFF0369A1)
                                summary.overallTier.startsWith("قابل قبول") -> Color(0xFFB45309)
                                else -> Color(0xFFDC2626)
                            },
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when {
                                summary.overallTier.startsWith("خیلی خوب") -> "⭐⭐⭐⭐"
                                summary.overallTier.startsWith("خوب") -> "⭐⭐⭐"
                                summary.overallTier.startsWith("قابل قبول") -> "⭐⭐"
                                else -> "⭐"
                            },
                            fontSize = 11.sp
                        )
                    }
                }

                // کارت تعداد غیبت‌ها
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (summary.totalAbsences == 0) Color(0xFFECFDF5) else Color(0xFFFEF2F2)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (summary.totalAbsences == 0) Color(0xFF6EE7B7) else Color(0xFFFCA5A5)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "تعداد غیبت‌ها", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (summary.totalAbsences == 0)
                                "۰ جلسه (عالی)"
                            else
                                "${DateUtils.toPersianDigits(summary.totalAbsences)} جلسه",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = if (summary.totalAbsences == 0) PrimaryGreenDark else Color(0xFFDC2626)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (summary.totalAbsences == 0)
                                "حضور منظم"
                            else
                                "${DateUtils.toPersianDigits(summary.unexcusedAbsences)} غیرموجه",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }

                // کارت ارزشیابی دروس
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                    border = BorderStroke(1.dp, Color(0xFFFED7AA))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "ارزشیابی دروس", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${DateUtils.toPersianDigits(summary.totalEvaluations)} مورد",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = Color(0xFFC2410C)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${DateUtils.toPersianDigits(summary.veryGoodCount)} خیلی خوب",
                            fontSize = 10.sp,
                            color = PrimaryGreenDark
                        )
                    }
                }
            }
        }

        // ۳. انتخابگر تب‌های تفصیلی
        item {
            ScrollableTabRow(
                selectedTabIndex = detailTab,
                edgePadding = 0.dp,
                containerColor = Color.White,
                contentColor = SkyBlue,
                divider = { HorizontalDivider(color = BorderLight) }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = detailTab == index,
                        onClick = { detailTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (detailTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp,
                                color = if (detailTab == index) SkyBlue else TextSecondary
                            )
                        }
                    )
                }
            }
        }

        // ۴. محتوای تب انتخاب‌شده
        when (detailTab) {
            0 -> {
                // --- تب تایم‌لاین وضعیت دقیق ---
                item {
                    // چیپ‌های فیلتر رویدادهای تایم‌لاین
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("همه رویدادها", "فقط غیبت‌ها 🚫", "فقط ارزشیابی‌ها 📝").forEachIndexed { index, label ->
                            FilterChip(
                                selected = timelineFilter == index,
                                onClick = { timelineFilter = index },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SkyBlue,
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White
                                )
                            )
                        }
                    }
                }

                val filteredTimeline = summary.timelineEvents.filter { item ->
                    when (timelineFilter) {
                        1 -> item is PerformanceTimelineItem.AttendanceRecordItem &&
                                (item.status == "غایب" || item.status == "غیرموجه" || item.status == "موجه")
                        2 -> item is PerformanceTimelineItem.EvaluationRecordItem
                        else -> true
                    }
                }

                if (filteredTimeline.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 30.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "هیچ رویدادی برای فیلتر انتخابی ثبت نشده است.",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    itemsIndexed(filteredTimeline) { index, event ->
                        TimelineEventCard(
                            event = event,
                            isLast = index == filteredTimeline.size - 1
                        )
                    }
                }
            }

            1 -> {
                // --- تب وضعیت به تفکیک هر درس ---
                item {
                    Text(
                        text = "عملکرد دانش‌آموز در دروس فعال کلاس",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                items(summary.subjectBreakdowns) { breakdown ->
                    SubjectBreakdownCard(breakdown = breakdown)
                }
            }

            2 -> {
                // --- تب آمار دقیق غیبت‌ها ---
                item {
                    DetailedAbsenceReportCard(summary = summary)
                }
            }

            3 -> {
                // --- تب کارنامه تحلیلی و دکمه کپی برای ارسال به اولیا ---
                item {
                    AnalyticalReportCard(
                        summary = summary,
                        onCopyReport = onCopyReport
                    )
                }
            }
        }
    }
}

// --- کامپوننت گره تایم‌لاین عمودی (Timeline Node) ---

@Composable
private fun TimelineEventCard(
    event: PerformanceTimelineItem,
    isLast: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
    ) {
        // ستون گره تایم‌لاین و خط اتصال عمودی
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(36.dp)
        ) {
            // گره دایره‌ای رویداد
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        when (event) {
                            is PerformanceTimelineItem.AttendanceRecordItem -> when (event.status) {
                                "غیرموجه" -> Color(0xFFEF4444)
                                "موجه" -> Color(0xFFF97316)
                                "غایب" -> Color(0xFFDC2626)
                                else -> Color(0xFF10B981)
                            }
                            is PerformanceTimelineItem.EvaluationRecordItem -> when (event.evaluation.score) {
                                "خیلی خوب" -> Color(0xFF10B981)
                                "خوب" -> SkyBlue
                                "قابل قبول" -> AmberSecondary
                                else -> Color(0xFFEF4444)
                            }
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (event) {
                        is PerformanceTimelineItem.AttendanceRecordItem -> when (event.status) {
                            "حاضر" -> Icons.Default.Check
                            "غیرموجه" -> Icons.Default.Close
                            "موجه" -> Icons.Default.EventBusy
                            else -> Icons.Default.PersonOff
                        }
                        is PerformanceTimelineItem.EvaluationRecordItem -> Icons.Default.School
                    },
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }

            // خط عمودی متصل‌کننده به رویداد بعدی
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(68.dp)
                        .background(BorderLight)
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // کارت اطلاعات رویداد
        Card(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = if (isLast) 0.dp else 12.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderLight),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // تاریخ و برچسب رویداد
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تاریخ: ${DateUtils.toPersianDigits(event.date)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (event) {
                            is PerformanceTimelineItem.AttendanceRecordItem -> when (event.status) {
                                "غیرموجه" -> Color(0xFFFEE2E2)
                                "موجه" -> Color(0xFFFFEDD5)
                                "غایب" -> Color(0xFFFEE2E2)
                                else -> Color(0xFFECFDF5)
                            }
                            is PerformanceTimelineItem.EvaluationRecordItem -> when (event.evaluation.score) {
                                "خیلی خوب" -> Color(0xFFECFDF5)
                                "خوب" -> Color(0xFFE0F2FE)
                                "قابل قبول" -> Color(0xFFFEF3C7)
                                else -> Color(0xFFFEE2E2)
                            }
                        }
                    ) {
                        Text(
                            text = when (event) {
                                is PerformanceTimelineItem.AttendanceRecordItem -> when (event.status) {
                                    "حاضر" -> "حاضر در کلاس"
                                    "غیرموجه" -> "غیبت غیرموجه"
                                    "موجه" -> "غیبت موجه"
                                    else -> "غیبت"
                                }
                                is PerformanceTimelineItem.EvaluationRecordItem -> event.evaluation.score
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (event) {
                                is PerformanceTimelineItem.AttendanceRecordItem -> when (event.status) {
                                    "غیرموجه" -> Color(0xFFDC2626)
                                    "موجه" -> Color(0xFFEA580C)
                                    "غایب" -> Color(0xFFDC2626)
                                    else -> Color(0xFF047857)
                                }
                                is PerformanceTimelineItem.EvaluationRecordItem -> when (event.evaluation.score) {
                                    "خیلی خوب" -> Color(0xFF047857)
                                    "خوب" -> Color(0xFF0369A1)
                                    "قابل قبول" -> Color(0xFFB45309)
                                    else -> Color(0xFFDC2626)
                                }
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // شرح رویداد
                when (event) {
                    is PerformanceTimelineItem.AttendanceRecordItem -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (event.status == "حاضر") Icons.Default.HowToReg else Icons.Default.Cancel,
                                contentDescription = null,
                                tint = if (event.status == "حاضر") PrimaryGreenDark else Color(0xFFDC2626),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (event.status) {
                                    "حاضr", "حاضر" -> "حضور فعال و به‌موقع در کلاس درس"
                                    "غیرموجه" -> "ثبت غیبت غیرموجه بدون ارائه گواهی یا اطلاع اولیا"
                                    "موجه" -> "ثبت غیبت موجه با اطلاع قبلی اولیا / مرخصی"
                                    else -> "غیبت در این روز کلاسی ثبت شده است"
                                },
                                fontSize = 12.sp,
                                color = TextPrimary
                            )
                        }
                    }
                    is PerformanceTimelineItem.EvaluationRecordItem -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = SkyBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "درس «${event.evaluation.subject}»",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ارزشیابی ${event.evaluation.type}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- کامپوننت وضعیت به تفکیک هر درس ---

@Composable
private fun SubjectBreakdownCard(breakdown: SubjectBreakdown) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(SkyBlue.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = breakdown.subjectName.firstOrNull()?.toString() ?: "د",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = SkyBlue
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = breakdown.subjectName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = if (breakdown.totalCount > 0)
                                "${DateUtils.toPersianDigits(breakdown.totalCount)} ارزشیابی ثبت‌شده"
                            else
                                "ارزشیابی ثبت‌نشده",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // بج وضعیت درس
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (breakdown.overallStatus) {
                        "خیلی خوب" -> Color(0xFF10B981).copy(alpha = 0.12f)
                        "خوب" -> SkyBlue.copy(alpha = 0.12f)
                        "قابل قبول" -> AmberSecondary.copy(alpha = 0.15f)
                        "نیاز به تلاش" -> Color(0xFFEF4444).copy(alpha = 0.12f)
                        else -> Color(0xFF94A3B8).copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = breakdown.overallStatus,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = when (breakdown.overallStatus) {
                            "خیلی خوب" -> Color(0xFF047857)
                            "خوب" -> Color(0xFF0369A1)
                            "قابل قبول" -> Color(0xFFB45309)
                            "نیاز به تلاش" -> Color(0xFFDC2626)
                            else -> Color(0xFF475569)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (breakdown.totalCount > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = BorderLight.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))

                // نمایش تفکیک نمرات این درس
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ScoreBadgeMini(label = "خیلی خوب", count = breakdown.veryGoodCount, color = Color(0xFF10B981))
                    ScoreBadgeMini(label = "خوب", count = breakdown.goodCount, color = SkyBlue)
                    ScoreBadgeMini(label = "قابل قبول", count = breakdown.acceptableCount, color = AmberSecondary)
                    ScoreBadgeMini(label = "نیاز به تلاش", count = breakdown.needsWorkCount, color = Color(0xFFEF4444))
                }

                if (breakdown.latestDate != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "آخرین ارزیابی: ${DateUtils.toPersianDigits(breakdown.latestDate)} (${breakdown.latestScore ?: ""})",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun ScoreBadgeMini(label: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "$label: ${DateUtils.toPersianDigits(count)}",
            fontSize = 11.sp,
            color = if (count > 0) TextPrimary else TextSecondary.copy(alpha = 0.6f),
            fontWeight = if (count > 0) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

// --- کامپوننت گزارش دقیق غیبت‌ها ---

@Composable
private fun DetailedAbsenceReportCard(summary: StudentPerformanceSummary) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = if (summary.totalAbsences == 0) PrimaryGreen else Color(0xFFDC2626),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "گزارش وضعیت حضور و غیاب",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // خلاصه آماری
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = PrimaryGreen.copy(alpha = 0.08f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "روزهای حضور", fontSize = 10.sp, color = TextSecondary)
                        Text(
                            text = DateUtils.toPersianDigits(summary.presentCount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PrimaryGreenDark
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFEE2E2)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "غیرموجه", fontSize = 10.sp, color = TextSecondary)
                        Text(
                            text = DateUtils.toPersianDigits(summary.unexcusedAbsences),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFFDC2626)
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFFEDD5)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "موجه", fontSize = 10.sp, color = TextSecondary)
                        Text(
                            text = DateUtils.toPersianDigits(summary.excusedAbsences),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFFEA580C)
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = SkyBlue.copy(alpha = 0.08f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "درصد حضور", fontSize = 10.sp, color = TextSecondary)
                        Text(
                            text = "${DateUtils.toPersianDigits(summary.attendanceRate)}٪",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = SkyBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (summary.absenceList.isEmpty()) {
                // کارت تقدیر عدم غیبت
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "حضور منظم و کامل در کلاس",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = PrimaryGreenDark
                            )
                            Text(
                                text = "این دانش‌آموز تا این لحظه هیچ غیبتی نداشته و حضور ۱۰۰٪ در جلسات داشته است.",
                                fontSize = 11.sp,
                                color = Color(0xFF065F46)
                            )
                        }
                    }
                }
            } else {
                Text(
                    text = "تاریخ‌های غیبت ثبت‌شده:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                summary.absenceList.forEach { (date, status) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (status == "غیرموجه") Icons.Default.Cancel else Icons.Default.EventBusy,
                                contentDescription = null,
                                tint = if (status == "غیرموجه") Color(0xFFDC2626) else Color(0xFFEA580C),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تاریخ: ${DateUtils.toPersianDigits(date)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (status == "غیرموجه") Color(0xFFFEE2E2) else Color(0xFFFFEDD5)
                        ) {
                            Text(
                                text = status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (status == "غیرموجه") Color(0xFFDC2626) else Color(0xFFEA580C),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- کامپوننت کارنامه تحلیلی و دکمه کپی برای ارسال به اولیا ---

@Composable
private fun AnalyticalReportCard(
    summary: StudentPerformanceSummary,
    onCopyReport: (String) -> Unit
) {
    val reportText = buildString {
        appendLine("📋 کارنامه و گزارش عملکرد تحصیلی و انضباطی")
        appendLine("👤 دانش‌آموز: ${summary.student.name}")
        if (summary.student.fatherName.isNotBlank()) appendLine("نام پدر: ${summary.student.fatherName}")
        if (summary.groupName != null) appendLine("گروه کلاسی: ${summary.groupName}")
        appendLine("------------------------------")
        appendLine("⭐ وضعیت کلی: ${summary.overallTier}")
        appendLine("📊 کل ارزشیابی‌ها: ${summary.totalEvaluations} مورد (${summary.veryGoodCount} خیلی خوب، ${summary.goodCount} خوب)")
        appendLine("📅 وضعیت حضور: ${summary.presentCount} روز حاضر (${summary.attendanceRate}٪)")
        appendLine("🚫 تعداد کل غیبت‌ها: ${summary.totalAbsences} جلسه (${summary.unexcusedAbsences} غیرموجه، ${summary.excusedAbsences} موجه)")
        appendLine("------------------------------")
        appendLine("📚 وضعیت دروس:")
        summary.subjectBreakdowns.forEach { b ->
            appendLine("• ${b.subjectName}: ${b.overallStatus} (${b.totalCount} ارزیابی)")
        }
        appendLine("------------------------------")
        appendLine("معلم کلاس - دبستان هوشمند")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = SkyBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "پیش‌نمایش گزارش عملکرد برای اولیا",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = BackgroundLight,
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = reportText,
                    fontSize = 12.sp,
                    color = TextPrimary,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { onCopyReport(reportText) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("copy_performance_report_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SkyBlue)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("کپی متن کارنامه جهت ارسال در شاد یا پیام‌رسان", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

// --- تابع محاسبه خلاصه عملکرد هر دانش‌آموز ---

private fun calculateStudentSummary(
    student: Student,
    subjects: List<SubjectItem>,
    attendanceHistory: List<DailyAttendance>,
    groups: List<GroupItem>,
    currentDate: String
): StudentPerformanceSummary {
    // ۱. استخراج تاریخ‌ها
    val allDates = (attendanceHistory.map { it.date } + listOf(currentDate))
        .filter { it.isNotBlank() }
        .distinct()

    var unexcused = 0
    var excused = 0
    var present = 0
    val absences = mutableListOf<Pair<String, String>>()
    val timelineEvents = mutableListOf<PerformanceTimelineItem>()

    allDates.forEach { date ->
        val status = if (date == currentDate) {
            student.status
        } else {
            val dayRecord = attendanceHistory.find { it.date == date }
            dayRecord?.records?.find { it.studentId == student.id }?.status ?: "حاضر"
        }

        val sortKey = DateUtils.toEnglishDigits(date).replace("/", "").padStart(8, '0')

        when (status) {
            "غیرموجه" -> {
                unexcused++
                absences.add(date to "غیرموجه")
                timelineEvents.add(PerformanceTimelineItem.AttendanceRecordItem(date, "غیرموجه", sortKey))
            }
            "موجه" -> {
                excused++
                absences.add(date to "موجه")
                timelineEvents.add(PerformanceTimelineItem.AttendanceRecordItem(date, "موجه", sortKey))
            }
            "غایب" -> {
                unexcused++
                absences.add(date to "غایب")
                timelineEvents.add(PerformanceTimelineItem.AttendanceRecordItem(date, "غایب", sortKey))
            }
            else -> {
                present++
                timelineEvents.add(PerformanceTimelineItem.AttendanceRecordItem(date, "حاضر", sortKey))
            }
        }
    }

    val totalAbsences = unexcused + excused
    val totalDays = totalAbsences + present
    val attendanceRate = if (totalDays > 0) ((present.toFloat() / totalDays) * 100).toInt() else 100

    // ۲. ارزشیابی‌ها
    val totalEvals = student.evaluations.size
    val veryGoodCount = student.evaluations.count { it.score == "خیلی خوب" }
    val goodCount = student.evaluations.count { it.score == "خوب" }
    val acceptableCount = student.evaluations.count { it.score == "قابل قبول" }
    val needsWorkCount = student.evaluations.count { it.score == "نیاز به تلاش" }

    student.evaluations.forEach { eval ->
        val sortKey = DateUtils.toEnglishDigits(eval.date).replace("/", "").padStart(8, '0')
        timelineEvents.add(PerformanceTimelineItem.EvaluationRecordItem(eval.date, eval, sortKey))
    }

    // مرتب‌سازی رویدادهای تایم‌لاین از جدیدترین به قدیمی‌ترین
    val sortedTimeline = timelineEvents.sortedByDescending { it.sortKey }

    // ۳. تفکیک به ازای هر درس
    val activeSubjects = subjects.filter { it.enabled }.ifEmpty { subjects }
    val subjectBreakdowns = activeSubjects.map { subject ->
        val subjectEvals = student.evaluations.filter { it.subject == subject.name }
        val vg = subjectEvals.count { it.score == "خیلی خوب" }
        val g = subjectEvals.count { it.score == "خوب" }
        val acc = subjectEvals.count { it.score == "قابل قبول" }
        val nw = subjectEvals.count { it.score == "نیاز به تلاش" }
        val latest = subjectEvals.maxByOrNull { DateUtils.toEnglishDigits(it.date).replace("/", "") }

        val status = when {
            subjectEvals.isEmpty() -> "در انتظار ارزیابی"
            vg >= g && vg >= acc && vg >= nw -> "خیلی خوب"
            g >= acc && g >= nw -> "خوب"
            acc >= nw -> "قابل قبول"
            else -> "نیاز به تلاش"
        }

        SubjectBreakdown(
            subjectName = subject.name,
            totalCount = subjectEvals.size,
            veryGoodCount = vg,
            goodCount = g,
            acceptableCount = acc,
            needsWorkCount = nw,
            latestScore = latest?.score,
            latestDate = latest?.date,
            overallStatus = status
        )
    }

    // ۴. وضعیت کلی
    val overallScoreOutOf4 = if (totalEvals > 0) {
        ((veryGoodCount * 4f) + (goodCount * 3f) + (acceptableCount * 2f) + (needsWorkCount * 1f)) / totalEvals
    } else {
        3.5f
    }

    val overallTier = when {
        totalEvals == 0 && totalAbsences == 0 -> "خیلی خوب (حضور منظم)"
        overallScoreOutOf4 >= 3.3f && totalAbsences <= 1 -> "خیلی خوب (سطح الف)"
        overallScoreOutOf4 >= 2.5f -> "خوب (سطح ب)"
        overallScoreOutOf4 >= 1.7f -> "قابل قبول (سطح ج)"
        else -> "نیازمند تلاش (سطح د)"
    }

    val groupName = groups.find { student.name in it.members }?.name

    return StudentPerformanceSummary(
        student = student,
        totalAbsences = totalAbsences,
        unexcusedAbsences = unexcused,
        excusedAbsences = excused,
        presentCount = present,
        attendanceRate = attendanceRate,
        absenceList = absences,
        totalEvaluations = totalEvals,
        veryGoodCount = veryGoodCount,
        goodCount = goodCount,
        acceptableCount = acceptableCount,
        needsWorkCount = needsWorkCount,
        overallTier = overallTier,
        overallScoreOutOf4 = overallScoreOutOf4,
        groupName = groupName,
        subjectBreakdowns = subjectBreakdowns,
        timelineEvents = sortedTimeline
    )
}
