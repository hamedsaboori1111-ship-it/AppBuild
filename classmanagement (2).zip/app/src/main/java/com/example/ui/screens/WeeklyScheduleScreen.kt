package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DaySchedule
import com.example.model.SubjectItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyScheduleScreen(
    weeklySchedule: List<DaySchedule>,
    availableSubjects: List<SubjectItem>,
    onBack: () -> Unit,
    onSaveSchedule: (List<DaySchedule>) -> Unit
) {
    val context = LocalContext.current
    val daysList = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")

    // State initialized from passed schedule, ensuring all 5 days exist
    val scheduleState = remember(weeklySchedule) {
        val map = weeklySchedule.associateBy { it.dayName }
        mutableStateMapOf<String, MutableList<String>>().apply {
            daysList.forEach { day ->
                val periods = map[day]?.periods ?: listOf("ریاضی", "فارسی و نگارش", "علوم تجربی", "قرآن و پیام‌های آسمان")
                put(day, periods.toMutableList())
            }
        }
    }

    var selectedDay by remember { mutableStateOf("شنبه") }

    // Dialog state for adding/editing a period
    var showPeriodDialog by remember { mutableStateOf(false) }
    var editingPeriodIndex by remember { mutableStateOf<Int?>(null) } // null means adding a new period
    var selectedSubjectName by remember { mutableStateOf("") }
    var customSubjectName by remember { mutableStateOf("") }

    // Quick suggestion list from available enabled subjects + common subjects
    val subjectSuggestions = remember(availableSubjects) {
        val fromState = availableSubjects.filter { it.enabled }.map { it.name }
        val defaults = listOf(
            "قرآن و پیام‌های آسمان",
            "فارسی و نگارش",
            "ریاضی",
            "علوم تجربی",
            "مطالعات اجتماعی",
            "هدیه‌های آسمان",
            "تربیت بدنی",
            "هنر و شایستگی",
            "فعالیت پرورشی",
            "تفکر و پژوهش"
        )
        (fromState + defaults).distinct()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "برنامه هفتگی کلاس درس",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val savedList = daysList.map { day ->
                                DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                            }
                            onSaveSchedule(savedList)
                            Toast.makeText(context, "برنامه هفتگی با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("save_all_schedule_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "ذخیره تغییرات",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryGreen,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editingPeriodIndex = null
                    selectedSubjectName = subjectSuggestions.firstOrNull() ?: "ریاضی"
                    customSubjectName = ""
                    showPeriodDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("افزودن زنگ جدید", fontWeight = FontWeight.Bold) },
                containerColor = PrimaryGreen,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_period_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // نوار انتخاب روز هفته (شنبه تا چهارشنبه)
            Surface(
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = PrimaryGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "روزهای تحصیلی هفته:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        val currentDayPeriodsCount = scheduleState[selectedDay]?.size ?: 0
                        Surface(
                            color = PrimaryGreen.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "$currentDayPeriodsCount زنگ درسی",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryGreenDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(daysList) { day ->
                            val isSelected = (day == selectedDay)
                            val count = scheduleState[day]?.size ?: 0

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) PrimaryGreen else Color(0xFFF1F5F9),
                                contentColor = if (isSelected) Color.White else TextPrimary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedDay = day }
                                    .testTag("day_tab_$day")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = day,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "$count زنگ",
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color.White.copy(alpha = 0.85f) else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // محتوای زنگ‌های روز انتخابی
            val currentPeriods = scheduleState[selectedDay] ?: mutableListOf()

            if (currentPeriods.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "برای $selectedDay زنگ درسی تعریف نشده است",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "با زدن دکمه «افزودن زنگ جدید» دروس این روز را مشخص کنید.",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        OutlinedButton(
                            onClick = {
                                editingPeriodIndex = null
                                selectedSubjectName = subjectSuggestions.firstOrNull() ?: "ریاضی"
                                customSubjectName = ""
                                showPeriodDialog = true
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("افزودن زنگ اول")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "لیست زنگ‌های $selectedDay:",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            TextButton(
                                onClick = {
                                    val savedList = daysList.map { day ->
                                        DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                                    }
                                    onSaveSchedule(savedList)
                                    Toast.makeText(context, "برنامه ذخیره شد", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ذخیره روز")
                            }
                        }
                    }

                    itemsIndexed(currentPeriods) { index, periodName ->
                        PeriodItemCard(
                            periodNumber = index + 1,
                            subjectName = periodName,
                            isFirst = index == 0,
                            isLast = index == currentPeriods.size - 1,
                            onEdit = {
                                editingPeriodIndex = index
                                selectedSubjectName = periodName
                                customSubjectName = ""
                                showPeriodDialog = true
                            },
                            onDelete = {
                                currentPeriods.removeAt(index)
                                // Trigger recomposition
                                scheduleState[selectedDay] = currentPeriods.toMutableList()
                                val savedList = daysList.map { day ->
                                    DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                                }
                                onSaveSchedule(savedList)
                            },
                            onMoveUp = {
                                if (index > 0) {
                                    val temp = currentPeriods[index]
                                    currentPeriods[index] = currentPeriods[index - 1]
                                    currentPeriods[index - 1] = temp
                                    scheduleState[selectedDay] = currentPeriods.toMutableList()
                                    val savedList = daysList.map { day ->
                                        DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                                    }
                                    onSaveSchedule(savedList)
                                }
                            },
                            onMoveDown = {
                                if (index < currentPeriods.size - 1) {
                                    val temp = currentPeriods[index]
                                    currentPeriods[index] = currentPeriods[index + 1]
                                    currentPeriods[index + 1] = temp
                                    scheduleState[selectedDay] = currentPeriods.toMutableList()
                                    val savedList = daysList.map { day ->
                                        DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                                    }
                                    onSaveSchedule(savedList)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // دیالوگ افزودن / ویرایش زنگ درسی
    if (showPeriodDialog) {
        var isCustom by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showPeriodDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (editingPeriodIndex == null) Icons.Default.AddCircle else Icons.Default.Edit,
                        contentDescription = null,
                        tint = PrimaryGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (editingPeriodIndex == null) "افزودن زنگ جدید به $selectedDay" else "ویرایش زنگ ${editingPeriodIndex!! + 1} $selectedDay",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "درس مورد نظر را از بین دروس انتخاب کرده یا نام دلخواه وارد کنید:",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // تب انتخاب درس یا ورودی دستی
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = !isCustom,
                            onClick = { isCustom = false },
                            label = { Text("دروس آماده") },
                            leadingIcon = {
                                if (!isCustom) Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                        FilterChip(
                            selected = isCustom,
                            onClick = { isCustom = true },
                            label = { Text("نام دلخواه / دیگر") },
                            leadingIcon = {
                                if (isCustom) Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }

                    if (!isCustom) {
                        // انتخاب دراپ‌داون یا چیپ‌های دروس
                        Text(
                            text = "انتخاب درس:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                        ) {
                            items(subjectSuggestions) { subj ->
                                val sel = (subj == selectedSubjectName)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (sel) PrimaryGreenLight else Color(0xFFF1F5F9),
                                    border = if (sel) androidx.compose.foundation.BorderStroke(1.dp, PrimaryGreen) else null,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selectedSubjectName = subj }
                                ) {
                                    Text(
                                        text = subj,
                                        fontSize = 12.sp,
                                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (sel) PrimaryGreenDark else TextPrimary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = selectedSubjectName,
                            onValueChange = { selectedSubjectName = it },
                            label = { Text("نام درس انتخاب شده") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("period_subject_picker_field"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    } else {
                        OutlinedTextField(
                            value = customSubjectName,
                            onValueChange = { customSubjectName = it },
                            label = { Text("نام درس جدید") },
                            placeholder = { Text("مثلاً: نقاشی و خوشنویسی") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("period_custom_subject_field"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalSubject = if (isCustom) customSubjectName.trim() else selectedSubjectName.trim()
                        if (finalSubject.isNotBlank()) {
                            val list = (scheduleState[selectedDay] ?: mutableListOf()).toMutableList()
                            if (editingPeriodIndex != null && editingPeriodIndex!! in list.indices) {
                                list[editingPeriodIndex!!] = finalSubject
                            } else {
                                list.add(finalSubject)
                            }
                            scheduleState[selectedDay] = list

                            // Auto save
                            val savedList = daysList.map { day ->
                                DaySchedule(dayName = day, periods = scheduleState[day] ?: emptyList())
                            }
                            onSaveSchedule(savedList)

                            showPeriodDialog = false
                            Toast.makeText(context, "زنگ درسی با موفقیت ثبت شد", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "لطفاً نام درس را مشخص کنید", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                    modifier = Modifier.testTag("confirm_period_button")
                ) {
                    Text("تأیید و ثبت", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPeriodDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}

@Composable
fun PeriodItemCard(
    periodNumber: Int,
    subjectName: String,
    isFirst: Boolean,
    isLast: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // شمارنده زنگ
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            when (periodNumber) {
                                1 -> PrimaryGreen.copy(alpha = 0.15f)
                                2 -> SkyBlue.copy(alpha = 0.15f)
                                3 -> AmberSecondary.copy(alpha = 0.15f)
                                4 -> TeacherTeal.copy(alpha = 0.15f)
                                else -> MeetingPurple.copy(alpha = 0.15f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$periodNumber",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = when (periodNumber) {
                            1 -> PrimaryGreenDark
                            2 -> SkyBlue
                            3 -> Color(0xFFB45309)
                            4 -> TeacherTeal
                            else -> MeetingPurple
                        }
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "زنگ $periodNumber",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subjectName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            // دکمه‌های عملیاتی: جابجایی بالا/پایین، ویرایش و حذف
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!isFirst) {
                    IconButton(
                        onClick = onMoveUp,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowUp,
                            contentDescription = "انتقال به زنگ قبل",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                if (!isLast) {
                    IconButton(
                        onClick = onMoveDown,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "انتقال به زنگ بعد",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "ویرایش زنگ",
                        tint = SkyBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف زنگ",
                        tint = Color(0xFFE53935),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
