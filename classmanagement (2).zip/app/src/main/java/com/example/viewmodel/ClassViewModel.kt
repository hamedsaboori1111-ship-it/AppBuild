package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ClassRepository
import com.example.model.AppState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class ClassViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ClassRepository(application.applicationContext)

    val state: StateFlow<AppState> = repository.state.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = repository.getDefaultState()
    )

    fun updateProfileSettings(teacherName: String, educationalTitle: String, schoolName: String) =
        repository.updateProfileSettings(teacherName, educationalTitle, schoolName)

    fun updateWeeklySchedule(schedule: List<com.example.model.DaySchedule>) =
        repository.updateWeeklySchedule(schedule)

    fun updateDaySchedule(dayName: String, periods: List<String>) =
        repository.updateDaySchedule(dayName, periods)

    fun setDate(date: String) = repository.setDate(date)
    fun syncWithDeviceDate(): String = repository.syncWithDeviceDate()
    fun setDayType(dayType: String) = repository.setDayType(dayType)
    fun updateStudentAttendance(studentId: Long, newStatus: String) =
        repository.updateStudentAttendance(studentId, newStatus)
    fun markAllStudentsPresent() = repository.markAllStudentsPresent()
    fun updateHistoricalAttendance(date: String, studentId: Long, newStatus: String) =
        repository.updateHistoricalAttendance(date, studentId, newStatus)
    fun markAllPresentForDate(date: String) =
        repository.markAllPresentForDate(date)
    fun addHistoricalAttendanceDate(date: String) =
        repository.addHistoricalAttendanceDate(date)
    fun deleteHistoricalAttendanceDate(date: String) =
        repository.deleteHistoricalAttendanceDate(date)
    fun addStudent(student: com.example.model.Student): Boolean =
        repository.addStudent(student)
    fun addStudent(name: String, shad: String, birthMonth: String): Boolean =
        repository.addStudent(name, shad, birthMonth)
    fun updateStudent(student: com.example.model.Student): Boolean =
        repository.updateStudent(student)
    fun deleteStudent(studentId: Long) = repository.deleteStudent(studentId)

    fun addEvaluation(studentId: Long, subject: String, type: String, score: String, date: String) =
        repository.addEvaluation(studentId, subject, type, score, date)
    fun deleteEvaluation(studentId: Long, evalId: String) =
        repository.deleteEvaluation(studentId, evalId)

    fun toggleSubject(subjectId: Long, enabled: Boolean) =
        repository.toggleSubject(subjectId, enabled)
    fun updateSubjectName(subjectId: Long, newName: String) =
        repository.updateSubjectName(subjectId, newName)
    fun addSubject(name: String) = repository.addSubject(name)
    fun deleteSubject(subjectId: Long) = repository.deleteSubject(subjectId)

    fun updateGroupScore(groupIndex: Int, delta: Int) =
        repository.updateGroupScore(groupIndex, delta)
    fun addGroup(name: String, members: List<String>) =
        repository.addGroup(name, members)
    fun updateGroup(groupIndex: Int, name: String, members: List<String>) =
        repository.updateGroup(groupIndex, name, members)
    fun updateGroupById(groupId: Long, name: String, members: List<String>) =
        repository.updateGroupById(groupId, name, members)
    fun deleteGroup(groupIndex: Int) = repository.deleteGroup(groupIndex)
    fun deleteGroupById(groupId: Long) = repository.deleteGroupById(groupId)

    fun addTeacherNote(title: String, content: String, date: String) =
        repository.addTeacherNote(title, content, date)
    fun deleteTeacherNote(id: Long) = repository.deleteTeacherNote(id)

    fun addParentMeeting(title: String, date: String, summary: String) =
        repository.addParentMeeting(title, date, summary)
    fun deleteParentMeeting(id: Long) = repository.deleteParentMeeting(id)

    fun exportDataJson(): String = repository.exportDataJson()
    fun importDataJson(jsonString: String): Boolean = repository.importDataJson(jsonString)

    fun listLocalBackups(): List<com.example.data.LocalBackupFile> = repository.listLocalBackups()
    fun createLocalBackup(title: String? = null): com.example.data.LocalBackupFile? = repository.createLocalBackup(title)
    fun restoreFromLocalBackup(file: java.io.File): Boolean = repository.restoreFromLocalBackup(file)
    fun deleteLocalBackup(file: java.io.File): Boolean = repository.deleteLocalBackup(file)
    fun exportBackupToUri(uri: android.net.Uri): Boolean = repository.exportBackupToUri(uri)
    fun importBackupFromUri(uri: android.net.Uri): Boolean = repository.importBackupFromUri(uri)
    fun parseBackupSummary(jsonString: String): com.example.data.BackupSummary = repository.parseBackupSummary(jsonString)
    fun readBackupFileText(file: java.io.File): String? = repository.readBackupFileText(file)
    fun shareBackup(context: android.content.Context, file: java.io.File) = repository.shareBackup(context, file)

    fun drawJusticeLeagueStudent() = repository.drawJusticeLeagueStudent()
    fun startNewJusticeLeague() = repository.startNewJusticeLeague()
    fun resetJusticeLeagueCurrentRound() = repository.resetJusticeLeagueCurrentRound()
}
