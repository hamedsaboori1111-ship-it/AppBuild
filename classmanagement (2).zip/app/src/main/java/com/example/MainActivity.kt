package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ClassViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ClassViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // جهت‌بندی راست‌به‌چپ (RTL) برای زبان فارسی، مطابق کدهای فلاتر
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        ClassManagerApp(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun ClassManagerApp(viewModel: ClassViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var currentScreen by remember { mutableStateOf(Screen.HOME) }

    // مدیریت دکمه بازگشت اندروید
    BackHandler(enabled = currentScreen != Screen.HOME) {
        currentScreen = Screen.HOME
    }

    AnimatedContent(
        targetState = currentScreen,
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            Screen.HOME -> {
                HomeScreen(
                    state = state,
                    onNavigate = { currentScreen = it },
                    onDateChange = { viewModel.setDate(it) },
                    onDayTypeChange = { viewModel.setDayType(it) },
                    onExportBackup = { viewModel.exportDataJson() },
                    onImportBackup = { viewModel.importDataJson(it) },
                    onSyncWithDeviceDate = { viewModel.syncWithDeviceDate() }
                )
            }
            Screen.PROFILE_SETTINGS -> {
                ProfileSettingsScreen(
                    profile = state.profile,
                    onBack = { currentScreen = Screen.HOME },
                    onSaveProfile = { teacherName, educationalTitle, schoolName ->
                        viewModel.updateProfileSettings(teacherName, educationalTitle, schoolName)
                    }
                )
            }
            Screen.SCHEDULE -> {
                WeeklyScheduleScreen(
                    weeklySchedule = state.weeklySchedule,
                    availableSubjects = state.subjects,
                    onBack = { currentScreen = Screen.HOME },
                    onSaveSchedule = { updatedSchedule ->
                        viewModel.updateWeeklySchedule(updatedSchedule)
                    }
                )
            }
            Screen.ATTENDANCE -> {
                AttendanceScreen(
                    students = state.students,
                    currentDate = state.currentDateShamsi,
                    attendanceHistory = state.attendanceHistory,
                    onBack = { currentScreen = Screen.HOME },
                    onStatusChange = { id, status -> viewModel.updateStudentAttendance(id, status) },
                    onMarkAllPresent = { viewModel.markAllStudentsPresent() },
                    onAddStudent = { name, shad, month -> viewModel.addStudent(name, shad, month) },
                    onSaveStudent = { student -> viewModel.addStudent(student) },
                    onUpdateStudent = { student -> viewModel.updateStudent(student) },
                    onDeleteStudent = { viewModel.deleteStudent(it) },
                    onUpdateHistoricalAttendance = { date, id, status ->
                        viewModel.updateHistoricalAttendance(date, id, status)
                    },
                    onMarkAllPresentForDate = { date ->
                        viewModel.markAllPresentForDate(date)
                    },
                    onAddHistoricalDate = { date ->
                        viewModel.addHistoricalAttendanceDate(date)
                    },
                    onDeleteHistoricalDate = { date ->
                        viewModel.deleteHistoricalAttendanceDate(date)
                    }
                )
            }
            Screen.EVALUATION -> {
                EvaluationScreen(
                    students = state.students,
                    subjects = state.subjects,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddEvaluation = { id, subject, type, score, date ->
                        viewModel.addEvaluation(id, subject, type, score, date)
                    },
                    onDeleteEvaluation = { studentId, evalId ->
                        viewModel.deleteEvaluation(studentId, evalId)
                    }
                )
            }
            Screen.GROUPS -> {
                GroupScoresScreen(
                    groups = state.groups,
                    students = state.students,
                    justiceLeague = state.justiceLeague,
                    onBack = { currentScreen = Screen.HOME },
                    onScoreChange = { index, delta -> viewModel.updateGroupScore(index, delta) },
                    onAddGroup = { name, members -> viewModel.addGroup(name, members) },
                    onUpdateGroup = { index, name, members -> viewModel.updateGroup(index, name, members) },
                    onDeleteGroup = { viewModel.deleteGroup(it) },
                    onDrawJusticeLeague = { viewModel.drawJusticeLeagueStudent() },
                    onStartNewLeague = { viewModel.startNewJusticeLeague() },
                    onResetLeague = { viewModel.resetJusticeLeagueCurrentRound() }
                )
            }
            Screen.SUBJECTS -> {
                SubjectManagementScreen(
                    subjects = state.subjects,
                    onBack = { currentScreen = Screen.HOME },
                    onToggle = { id, enabled -> viewModel.toggleSubject(id, enabled) },
                    onRename = { id, newName -> viewModel.updateSubjectName(id, newName) },
                    onAddSubject = { viewModel.addSubject(it) },
                    onDeleteSubject = { viewModel.deleteSubject(it) }
                )
            }
            Screen.NOTES -> {
                TeacherNotesScreen(
                    notes = state.teacherNotes,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddNote = { title, content, date -> viewModel.addTeacherNote(title, content, date) },
                    onDeleteNote = { viewModel.deleteTeacherNote(it) }
                )
            }
            Screen.MEETINGS -> {
                ParentMeetingsScreen(
                    meetings = state.parentMeetings,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME },
                    onAddMeeting = { title, date, summary -> viewModel.addParentMeeting(title, date, summary) },
                    onDeleteMeeting = { viewModel.deleteParentMeeting(it) }
                )
            }
            Screen.PERFORMANCE -> {
                StudentPerformanceScreen(
                    students = state.students,
                    subjects = state.subjects,
                    attendanceHistory = state.attendanceHistory,
                    groups = state.groups,
                    currentDate = state.currentDateShamsi,
                    onBack = { currentScreen = Screen.HOME }
                )
            }
            Screen.BACKUP_RESTORE -> {
                BackupRestoreScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = Screen.HOME }
                )
            }
        }
    }
}

// Greeting function kept for backward test compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("دفتر مدیریت کلاس") }
}
