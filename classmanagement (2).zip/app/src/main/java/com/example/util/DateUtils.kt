package com.example.util

import java.util.Calendar

object DateUtils {

    private val PERSIAN_MONTH_NAMES = arrayOf(
        "فروردین", "اردیبهشت", "خرداد",
        "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر",
        "دی", "بهمن", "اسفند"
    )

    data class JalaliDate(
        val year: Int,
        val month: Int,
        val day: Int,
        val dayOfWeekName: String,
        val monthName: String
    ) {
        /**
         * Formats as Persian digits e.g. "۱۴۰۳/۰۷/۱۵"
         */
        fun toFormattedString(): String {
            val y = year.toString()
            val m = month.toString().padStart(2, '0')
            val d = day.toString().padStart(2, '0')
            return toPersianDigits("$y/$m/$d")
        }

        /**
         * Formats as full Persian string e.g. "شنبه ۲۱ شهریور ۱۴۰۵"
         */
        fun toFullDisplayString(): String {
            val d = toPersianDigits(day.toString())
            val y = toPersianDigits(year.toString())
            return "$dayOfWeekName $d $monthName $y"
        }
    }

    fun toPersianDigits(text: String): String {
        return text.map { char ->
            when (char) {
                '0' -> '۰'
                '1' -> '۱'
                '2' -> '۲'
                '3' -> '۳'
                '4' -> '۴'
                '5' -> '۵'
                '6' -> '۶'
                '7' -> '۷'
                '8' -> '۸'
                '9' -> '۹'
                else -> char
            }
        }.joinToString("")
    }

    fun toPersianDigits(number: Number): String {
        return toPersianDigits(number.toString())
    }

    fun toEnglishDigits(text: String): String {
        return text.map { char ->
            when (char) {
                '۰' -> '0'
                '۱' -> '1'
                '۲' -> '2'
                '۳' -> '3'
                '۴' -> '4'
                '۵' -> '5'
                '۶' -> '6'
                '۷' -> '7'
                '۸' -> '8'
                '۹' -> '9'
                else -> char
            }
        }.joinToString("")
    }

    /**
     * Converts Gregorian Year, Month (1-12), Day (1-31) to Jalali (Solar Hijri) date.
     * Uses the standard and precise astronomical conversion algorithm.
     */
    fun gregorianToJalali(gy: Int, gm: Int, gd: Int, dayOfWeekCalendarConstant: Int = -1): JalaliDate {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

        val gy2 = gy - 1600
        val gm2 = gm - 1
        val gd2 = gd - 1

        var gDayNo = 365 * gy2 + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400
        for (i in 0 until gm2) {
            gDayNo += gDaysInMonth[i]
        }
        if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))) {
            gDayNo++
        }
        gDayNo += gd2

        var jDayNo = gDayNo - 79

        val jNp = jDayNo / 12053
        jDayNo %= 12053

        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461

        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }

        var jm = 0
        while (jm < 11 && jDayNo >= jDaysInMonth[jm]) {
            jDayNo -= jDaysInMonth[jm]
            jm++
        }
        val jd = jDayNo + 1
        val jMonth1Based = jm + 1

        val dayName = when (dayOfWeekCalendarConstant) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> ""
        }

        val monthName = if (jMonth1Based in 1..12) PERSIAN_MONTH_NAMES[jMonth1Based - 1] else ""

        return JalaliDate(
            year = jy,
            month = jMonth1Based,
            day = jd,
            dayOfWeekName = dayName,
            monthName = monthName
        )
    }

    /**
     * Gets the exact current Jalali date strictly based on the phone's current time.
     */
    fun getCurrentJalaliDate(): JalaliDate {
        val cal = Calendar.getInstance()
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        return gregorianToJalali(gy, gm, gd, dow)
    }

    /**
     * Returns the formatted Shamsi date (e.g. "۱۴۰۵/۰۶/۲۲") from the phone's clock.
     */
    fun getCurrentShamsiDate(): String {
        return getCurrentJalaliDate().toFormattedString()
    }

    /**
     * Returns the full Persian display text (e.g. "شنبه ۲۲ شهریور ۱۴۰۵") from the phone's clock.
     */
    fun getCurrentShamsiFullText(): String {
        return getCurrentJalaliDate().toFullDisplayString()
    }

    /**
     * Returns today's day of week in Persian (شنبه تا جمعه).
     */
    fun getCurrentDayOfWeek(): String {
        val cal = Calendar.getInstance()
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> "شنبه"
        }
    }
}
